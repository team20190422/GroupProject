#include "Obstracle.h"
#include "GameTask.h"
#include "ImageMng.h"

constexpr int OBST_SIZE = 25;

Obstracle::Obstracle()
{
	pos = { (float)SCREEN_SIZE_X / 2,(float)SCREEN_SIZE_Y};
	speed = 3.0f;
	o.left = (long)(pos.x - size.x / 2);
	o.right = (long)(pos.x + size.x / 2);
	o.top = (long)(pos.y - size.y / 2);
	o.bottom = (long)(pos.y + size.y / 2);
	LoadDivGraph("image/Explosion/����_��.png", 11, 11, 1, 115, 100, expAnim, true);
}


Obstracle::~Obstracle()
{
}

void Obstracle::Update()
{
	SetMove();
	//��`�̃T�C�Y��ݒ�(��Q��)
	int o_width = o.right - o.left;
	int o_height = o.bottom - o.top;
	if (!lpGameTask.GetDB())
	{
		SetRect(&o, pos.x - size.x / 2, pos.y - size.y / 2, pos.x + o_width / 2, pos.y + o_height / 2);
	}
	//��`�̃T�C�Y��`��(�f�o�b�O�p)
	//DrawBox(o.left,o.top, o.right, o.bottom, GetColor(255, 0, 0), false);
	//DrawFormatString(10, 40, GetColor(255, 255, 255), "posX�@%f  posY %f", pos.x, pos.y);

	planetPos.resize(lpGameTask.planetMax);
	planetGravity.resize(lpGameTask.planetMax);
	distanceMin = 10000.0f;
	for (int i = 0; i < lpGameTask.planetMax; i++)
	{
		planetPos[i] = lpGameTask.GetPlanetPosition(i);
		planetGravity[i] = lpGameTask.GetPlanetGravity(i);

		float a = abs(planetPos[i].x - pos.x);
		float b = abs(planetPos[i].y - pos.y);
		distance = sqrt((a * a) + (b * b));
		if (distance < distanceMin)
		{
			distanceMin = distance;
			planetPosSave = planetPos[i];
			saveGravity = planetGravity[i];
		}
	}
	auto angle = atan2(planetPosSave.x - pos.x, planetPosSave.y - pos.y);
	gVec.x = sin(angle);
	gVec.y = -cos(angle);
	EofG = saveGravity * 15;
	mgn = sqrt((vec.x * vec.x) + (vec.y * vec.y));
	uniVec = vec / mgn;
	//DrawFormatString(20, SCREEN_SIZE_Y / 2 + 20, 0xffffff, "Gravity:%f", EofG);
	addVec = (Obj::Normalize(gVec, distanceMin) * EofG) + uniVec;
	test = (Obj::Normalize(gVec, distanceMin) * EofG);
	//DrawFormatString(50, SCREEN_SIZE_Y / 2, 0xffffff, "addVec.x:%.3f,addVec.y:%.3f", addVec.x, addVec.y);
	//DrawFormatString(50, SCREEN_SIZE_Y / 2 + 15, 0xffffff, "EofG:%.3f", EofG);
	//DrawFormatString(50, SCREEN_SIZE_Y / 2 + 30, 0xffffff, "distanceMin:%.3f", distanceMin);
	//DrawFormatString(50, SCREEN_SIZE_Y / 2 + 45, 0xffffff, "vec.x:%.3f,vec.y:%.3f", uniVec.x, uniVec.y);
	//DrawFormatString(50, SCREEN_SIZE_Y / 2, 0xffffff, "X:%f,Y:%f", test.x,test.y);
	//SetVector(addVec);
	lpGameTask.SetObstPos(pos);

	if (lpGameTask.GetHitObstAst())
	{
		lpGameTask.SetHitObstAst(false);
		expFlag = true;
	}

	if (expFlag)
	{
		count++;
		anim = count / 5 % 11;
		auto scrpos = pos + lpGameTask.GetScrollPos();
		DrawRotaGraphF(pos.x, scrpos.y,0.5,0,expAnim[anim], true);
		//DrawRotaGraphF
		if (anim >= 10)
		{
			count = 0;
			expFlag = false;
			pos.y = -OBST_SIZE;
			pos.x = GetRand(SCREEN_SIZE_X);

		}
	}
}

void Obstracle::Draw()
{
	if (!expFlag)
	{
		DrawGraph(pos.x - size.x / 2 + lpGameTask.GetScrollPos().x, pos.y - size.y / 2 + lpGameTask.GetScrollPos().y, IMAGE_ID(imageName), true);
	}
	//DrawFormatString(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 0xffffff, "x:%fy:%f", lpGameTask.GetScrollPos().x, lpGameTask.GetScrollPos().y);
	//DrawLine(pos.x, pos.y, planetPosSave.x, planetPosSave.y, 0xffff00, true);
	//DrawLine(pos.x, pos.y - SCREEN_SIZE_Y, pos.x, pos.y+ SCREEN_SIZE_Y, GetColor(255, 255, 255), true);
}

void Obstracle::SetMove()
{
	if (!expFlag)
	{
		pos += addVec * speed;
		fPos.x = pos.x;
		fPos.y = pos.y + 100;
		vec = { fPos.x - pos.x,fPos.y - pos.y };
		//DrawLine(fPos.x, fPos.y, pos.x, pos.y, 0xffffff, true);
		if (pos.y > SCREEN_SIZE_Y + OBST_SIZE)
		{
			pos.y = -OBST_SIZE;
			pos.x = GetRand(SCREEN_SIZE_X);
		}
	}
	else
	{
		pos = pos + lpGameTask.GetScrollPos();
	}
}

bool Obstracle::SetPos(VECTOR3 pos)
{
	this->pos = pos;
	return false;
}

RECT  &Obstracle::GetRect()
{
	return this->o;
}
