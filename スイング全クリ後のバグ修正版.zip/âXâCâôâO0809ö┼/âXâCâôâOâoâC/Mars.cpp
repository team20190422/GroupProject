#include <DxLib.h>
#include "Mars.h"
#include "GameTask.h"
#include "ImageMng.h"
#include "UnivGravityCalc.h"

constexpr float PI = 3.1415;

Mars::Mars(VECTOR3 pos, int marsCnt, UnivGravityCalc& u): univ(u)
{
	mPos = pos;
	imageCnt = marsCnt;
	Init();
}

Mars::~Mars()
{
}

bool Mars::SetPos(VECTOR3 pos)
{
	this->pos = pos;
	return false;
}

const VECTOR3 & Mars::GetPos(void)
{
	return pos;
}

void Mars::Init()
{
	image = (imageCnt == 1 ? LoadGraph("image/Mars.png") : (imageCnt == 2 ? LoadGraph("image/JupiterTest.png") : LoadGraph("image/Neptune.png")));
	planetImage = (imageCnt == 1 ? LoadSoftImage("image/Mars.png") : (imageCnt == 2 ? LoadSoftImage("image/JupiterTest.png") : LoadSoftImage("image/Neptune.png")));
	nextPlanet = LoadGraph("image/nextPlanet.png");
	mokutekichi = LoadGraph("image/mokutekichi.png");
	r = (float)BasePlanet::GetRadius(image);
	GetGraphSize(image, &imageSize.x, &imageSize.y);
	pos = mPos;

	univ.AddAstMass(mass);
	univ.AddAstPos(pos);
}

void Mars::Update()
{
	auto HitCheck = [&] {
		int r = 0, g = 0, b = 0, a = 0;
		unsigned int rSize = (PLAYER_SIZE / 4);

		VECTOR3 playerPosR(lpGameTask.playerPos.x + rSize, lpGameTask.playerPos.y + rSize);
		VECTOR3 playerPosL(lpGameTask.playerPos.x - rSize, lpGameTask.playerPos.y - rSize);

		if (!lpGameTask.GetMutekiFlag())
		{
			for (int x = 0; x < imageSize.x; x++)
			{
				for (int y = 0; y < imageSize.y; y++)
				{
					GetPixelSoftImage(planetImage, x, y, &r, &g, &b, &a);

					if (a > 60)
					{
						VECTOR3 marsPos(pos.x - (imageSize.x / 2) + x, pos.y - imageSize.y / 2 + y);
						//DrawPixel((int)marsPos.x, (int)marsPos.y, GetColor(255, 0, 0));
						if ((marsPos.x > playerPosL.x && marsPos.x < playerPosR.x))
						{
							if ((marsPos.y > playerPosL.y && marsPos.y < playerPosR.y))
							{
								return true;
							}
						}
					}
				}
			}
		}
		//PtoP = lpGameTask.GetPlanetToPlayerVectorCalc(pos, lpGameTask.playerPos);
		//PtoPVector[lpGameTask.planetMax - 1] = PtoP;

		//dist = sqrt((PtoP.x * PtoP.x) + (PtoP.y * PtoP.y));
		//univG[lpGameTask.planetMax - 1] = UnivGravity(mass,PLAYER_MASS,dist);
		//lpGameTask.SetPlanetGravity(lpGameTask.planetMax - 1, univG[lpGameTask.planetMax - 1]);
		//lpGameTask.SetPlanetToPlayerVector(lpGameTask.planetMax - 1, PtoPVector[lpGameTask.planetMax - 1]);
		//lpGameTask.SetPlanetToPlayerDistance(lpGameTask.planetMax - 1, dist);

		return false;
	};
	unsigned int rSize = (PLAYER_SIZE);
	VECTOR3 playerPosR(lpGameTask.playerPos.x + rSize, lpGameTask.playerPos.y + rSize);
	time += 0.01f;
	radianPos = VECTOR3(pos.x + (r * cos(-imageCnt / 2)), pos.y + (r * sin(-imageCnt / 2)));

	lpGameTask.targetSize = r;
	lpGameTask.targetPos = radianPos;
	lpGameTask.targetVec = (radianPos - pos);

	if (!lpGameTask.GetHitCheck() && !lpGameTask.GetLandCheck())
	{
		if (!lpGameTask.plPosMaxFlag)
		{

			pos = pos + lpGameTask.GetScrollPos();
		}
	}


	if (!lpGameTask.landingFlag && (playerPosR.x > radianPos.x - rSize && lpGameTask.playerPos.x < radianPos.x + rSize))
	{

		if (!lpGameTask.landingFlag && (playerPosR.y > radianPos.y - rSize && lpGameTask.playerPos.y < radianPos.y + rSize))
		{
			//DrawString((int)lpGameTask.playerPos.x, (int)lpGameTask.playerPos.y + rSize, "Get", 0xffffff, true);
			lpGameTask.SetLandCheck(true);
			lpGameTask.getSample = true;
		}
		else if (HitCheck() && !lpGameTask.GetLandCheck())
		{
			lpGameTask.SetHitCheck(true);
		}
		else
		{
			lpGameTask.SetHitCheck(false);
		}
	}
	else if (HitCheck() && !lpGameTask.GetLandCheck())
	{
		
		lpGameTask.SetHitCheck(true);
	}
	else
	{
		lpGameTask.SetHitCheck(false);
	}

	if (!lpGameTask.landingFlag)
	{
		if (light < 0)
		{
			light = 255;
		}
		else
		{
			light -= 5.0f;
		}
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, light);
		//DrawBox((int)radianPos.x - rSize, (int)radianPos.y - rSize, (int)radianPos.x + rSize / 2, (int)radianPos.y + rSize / 2, GetColor(255, 0, 0), true);
		int color;
		if (lpGameTask.GetStageCnt() == 0)
		{
			color = GetColor(0, 0, 255);
		}
		else if (lpGameTask.GetStageCnt() == 1)
		{
			color = GetColor(0, 255, 0);
		}
		else if (lpGameTask.GetStageCnt() == 2)
		{
			color = GetColor(255, 0, 0);
		}
		else
		{
			color = 1;
		}

 		DrawCircle((int)radianPos.x, (int)radianPos.y,15, color, true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

	}
	lpGameTask.SetPlPosY(pos.y);

	univ.SetAstPos(lpGameTask.planetMax - 1, pos);

}

void Mars::Draw()
{
	Angle = atan2(radianPos.y - pos.y, radianPos.x - pos.x) + 1.5f;
	planetTime++;

	// nextPlanet
	DrawRotaGraphF(pos.x, pos.y,1.0,0,image, true);

	SetDrawBlendMode(DX_BLENDMODE_ALPHA, lpGameTask.GetUIAlpha());
	DrawRotaGraph(55, 110, (imageCnt != 2 ? 0.5 : 0.3), 0, image, true);
	DrawRotaGraph(80, 55, 1, 0, mokutekichi, true);
	DrawRotaGraph(55, 110, 1.0, 0, nextPlanet, true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, lpGameTask.GetUIAlpha());
	if (!lpGameTask.landingFlag && imageCnt == 1)
	{
		auto planetDis =lpGameTask.playerPos.x - radianPos.x;
		if (planetDis <= 255)
		{
			SetDrawBlendMode(DX_BLENDMODE_ALPHA, planetDis);

		}
		DrawRotaGraph(radianPos.x + sin(PI * 2 / 300 * planetTime) * 5, radianPos.y, 0.8, Angle, IMAGE_ID("image/���.png"), true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
	}
	//DrawFormatString(100, 730, 0xffffff, "MrS: posX:%f posY:%f", pos.x, pos.y);

	//DrawGraph(pos.x, pos.y, image, true);
}
