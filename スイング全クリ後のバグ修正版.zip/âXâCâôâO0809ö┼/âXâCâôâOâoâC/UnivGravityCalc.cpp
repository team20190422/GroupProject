#include "UnivGravityCalc.h"
#include "GameTask.h"


UnivGravityCalc::UnivGravityCalc()
{
}


UnivGravityCalc::~UnivGravityCalc()
{
}

void UnivGravityCalc::AddAstPos(VECTOR3 ast)
{
	astPos.push_back(ast);
}

void UnivGravityCalc::SetAstPos(int i, VECTOR3 pos)
{
	astPos[i] = pos;
}

void UnivGravityCalc::AddAstMass(float m)
{
	mass.push_back(m);
}

VECTOR3 UnivGravityCalc::GravityValue(int i,VECTOR3 pos)
{
	if (lpGameTask.GetMutekiFlag() && i == lpGameTask.planetMax - 2)
	{
		return VECTOR3(0, 0);
	}
	auto PtoP = lpGameTask.GetPlanetToPlayerVectorCalc(astPos[i], pos);

	/*PtoPVector.resize(lpGameTask.planetMax);
	PtoPVector[i] = PtoP;*/
	auto dist = sqrt((PtoP.x * PtoP.x) + (PtoP.y * PtoP.y));
	/*distance.resize(lpGameTask.planetMax);
	distance[i] = dist;*/
	/*univG.resize(lpGameTask.planetMax);
	univG[i] = UnivGravity(mass, PLAYER_MASS, dist);*/
	auto univG = UnivGravity(mass[i], PLAYER_MASS, dist);

	auto addVec = Obj::Normalize(PtoP, dist) * univG;

	return addVec;
}

float UnivGravityCalc::UnivGravity(float M, float m, float r)
{
	float G = 6.0f;		// ���L���͒萔
	return (G * M * m) / (r * r);
}
