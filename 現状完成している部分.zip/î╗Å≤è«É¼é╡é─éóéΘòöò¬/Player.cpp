#include "Player.h"
#include "ImageMng.h"
#include "Particle.h"

constexpr unsigned int posY_Max = (float)SCREEN_SIZE_Y - (float)SCREEN_SIZE_Y / 3;

Player::Player(const int(&trgKey)[KEY_MAX], const int(&oldKey)[KEY_MAX]) :Obj(trgKey, oldKey)
{
	particleList.clear();
	MaxFlag = false;
	pos = { (float)SCREEN_SIZE_X / 2, (float)SCREEN_SIZE_Y - (float)SCREEN_SIZE_Y / 3 };
	radianPos = { pos.x,pos.y };
	plPos = pos;
}


Player::~Player()
{
}

void Player::Draw(void)
{

	Angle = atan2(radianPos.y - pos.y, radianPos.x - pos.x) + 1.5f;
	if (lpGameTask.setCount)
	{
		count -= 6.0f;
		vec = -vec;
		lpGameTask.setCount = false;
	}

	turnPos.x = pos.x + (13 * cos(count / 2));
	turnPos.y = pos.y + (13 * sin(count / 2));

	if (sideCheck)
	{
		sidePos.x = turnPos.x + ((13 * sin(-count / 2)) * (sideCheck == 2 ? 1 : -1));
		sidePos.y = turnPos.y + ((13 * cos(count / 2)) * (sideCheck == 2 ? 1 : -1));

	}
	else
	{
		sidePos.x = pos.x + (13 * cos(count / 2));
		sidePos.y = pos.y + (13 * sin(count / 2));
	}

	if (!lpGameTask.GetHitCheck())
	{

		for (auto itr : particleList)
		{
			itr->Draw();
			itr->Update();

		}
		for (auto itr : sideParticleList)
		{
			itr->Draw();
			itr->Update();
		}


		DrawRotaGraph(pos.x, pos.y, Size, Angle, IMAGE_ID(imageName), true);

		if (pos.x < -32)
		{
			lpGameTask.OutOfScreen = true;
			DrawTriangle(0, pos.y, 20, pos.y + 5, 20, pos.y - 5, 0xffffff, true);
			DrawCircle(45, pos.y, 35, GetColor(255, 255, 255), true);
			DrawCircle(45, pos.y, 32, GetColor(0, 0, 0), true);
			DrawRotaGraph(45, pos.y, 1.0, Angle, IMAGE_ID("image/player3.png"), true);
		}
		else if (pos.x > SCREEN_SIZE_X + PLAYER_SIZE)
		{
			lpGameTask.OutOfScreen = true;
			DrawTriangle(SCREEN_SIZE_X, pos.y, SCREEN_SIZE_X - 20, pos.y + 5, SCREEN_SIZE_X - 20, pos.y - 5, 0xffffff, true);
			DrawCircle(SCREEN_SIZE_X - 45, pos.y, 35, GetColor(255, 255, 255), true);
			DrawCircle(SCREEN_SIZE_X - 45, pos.y, 32, GetColor(0, 0, 0), true);
			DrawRotaGraph(SCREEN_SIZE_X - 45, pos.y, 1.0, Angle, IMAGE_ID("image/player3.png"), true);
		}
		else
		{
			lpGameTask.OutOfScreen = false;
		}
		/*DrawLine(pos.x - 16, pos.y, pos.x + 16, pos.y, GetColor(255, 255, 255), true);
		DrawLine(pos.x, pos.y - 16, pos.x, pos.y + 16, GetColor(0, 255, 255), true);

		DrawLine(pos.x, pos.y, newPrePos.x + pos.x, newPrePos.y + pos.y, GetColor(0, 255, 255), true);
		DrawLine(pos.x, pos.y, newPos.x, newPos.y, GetColor(0, 255, 0), true);*/
	}
	else
	{
		for (int i = 0; i < particleMax; i++)
		{
			if (particleList.size() > 0)
			{
				if (!(particleList.empty()))
				{
					particleList.pop_front();
				}
			}
		}
		speed = 0.5f;
		distance = 1000;
		count = -3.0f;
		rolInc = 0.0f;
		lrFlag = 0;
	}


	/*DrawCircle(turnPos.x, turnPos.y,2, GetColor(255, 255, 255),true);
	DrawCircle(radianPos.x, radianPos.y, 2, GetColor(255, 255, 255), true);
	DrawCircle(newPos.x, newPos.y, 2, GetColor(255, 255, 255), true);
	DrawCircle(newPrePos.x + pos.x, newPrePos.y + pos.y, 2, GetColor(255, 255, 255), true);*/

	//DrawCircle(sidePos.x, sidePos.y, 2, GetColor(255, 255, 0), true);

	SetFontSize(25);		// ̫�Ă̻���
	SetFontThickness(5);	// ̫�Ă̑���
	ChangeFont("Ailerons");

	// �V�X�e��UI
	DrawGraph(105, 75, IMAGE_ID("image/speedUI_under.png"), true);
	DrawGraph(105, 105, IMAGE_ID("image/speedUI_under.png"), true);
	DrawBox(110, 155, 110 + (energy * 1.4f), 160, GetColor(255, 55 + (energy / 5), 55 + (energy / 5)), true);
	DrawGraph(105, 135, IMAGE_ID("image/engine_under.png"), true);

	//DrawExtendGraph(5, 35, 145, 65, IMAGE_ID("image/speed.png"), true);
	//DrawExtendGraph(-50, 70, 90, 110, IMAGE_ID("image/distance.png"), true);
	//DrawExtendGraph(5, 100, 145, 150, IMAGE_ID("image/fuel.png"), true);

	DrawGraph(100, 63, IMAGE_ID("image/sokudoUI.png"), true);
	DrawGraph(100, 93, IMAGE_ID("image/kyoriUI.png"), true);
	DrawGraph(100, 123, IMAGE_ID("image/nenryouUI.png"), true);

	DrawFormatString(175, 68, GetColor(255, 255, 255), "%.0fkm/s", speed * 4);
	DrawFormatString(175, 98, GetColor(255, 255, 255), "%dkm", (int)lpGameTask.targetDistance);
	DrawFormatString(200, 128, GetColor(255, 255, 255), "%.0fl", energy);


	SetFontSize(20);		// ̫�Ă̻���
	SetFontThickness(8);	// ̫�Ă̑���
	ChangeFont("MS�S�V�b�N");
	
	if (energy < 0)
	{
		energy = 0;
	}
}

void Player::Update(void)
{
	radianPos.x = pos.x + (100 * cos(count / 2));
	radianPos.y = pos.y + (100 * sin(count / 2));


	PreAngle = atan2(radianPos.y - pos.y, radianPos.x - pos.x) + 1.5f;
	PreAngle2 = atan2(newPrePos.y, newPrePos.x) + 1.5f;

	
	newPos.x = (pos.x) + (50 * cos(newcount / 2));
	newPos.y = (pos.y) + (50 * sin(newcount / 2));


	p.left = (long)(pos.x - size.x / 2);
	p.right = (long)(pos.x + size.x / 2);
	p.top = (long)(pos.y - size.y / 2);
	p.bottom = (long)(pos.y + size.y / 2);

	if (sideParticleList.size() > 0)
	{
		//(*sideParticle)->SetPos(turnPos + VECTOR3((sideCheck == 0 ? 0 : (sideCheck == 1 ? -10 : 10)), 0));
	}
	// ������
	if (!lpGameTask.GetHitCheck())
	{
		if (lpGameTask.GetLandCheck())
		{
			speed = 0.13f;
			if (landingTime++ % 3 == 0)
			{
				Size -= 0.01f;
			}
			if (Size <= 0.7)
			{
				lpGameTask.landingFlag = true;
			}
		}
		else
		{
			if (Size != 1.0f)
			{
				Size = 1.0f;
			}
		}

		SetMove();
	}
	else 
	{
		for (int i = 0; i < particleMax; i++)
		{
			if (particleList.size() > 0)
			{
				if (!(particleList.empty()))
				{
					particleList.pop_front();
				}
			}
		}
		speed = 0;
		distance = 1000;
		gVec = VECTOR3(0,0);

	}


	if (energy < 20)
	{
		WarningDownFlag = true;
		warningPosUp.x += 1;
		//if (warningPosUp.x > SCREEN_SIZE_X)
		//{
		//	warningPosUp.x = -450;
		//	DrawGraph(warningPosUp.x, warningPosUp.y, IMAGE_ID("image/warning!.png"), true);
		//}
	}
	else
	{
		WarningDownFlag = false;
		warningPosUp.x = -450;
	}
	if (WarningDownFlag == true)
	{
		warningDown++;
		if (warningDown > 35)
		{
			warningDown = 35;
			lineFlag = true;
		}
		DrawBox(0, 0, SCREEN_SIZE_X, warningDown, 0xffff00, true);

		if (lineFlag == true)
		{
			//�폜
			if (BlackLine.size() > 0)
			{
				if (BlackLine.begin()->x > (SCREEN_SIZE_X / 10))
				{
					BlackLine.erase(BlackLine.begin());
					blSize--;
				}
			}
			if (warning.size() > 0)
			{
				if (warning.begin()->x > SCREEN_SIZE_X * 1.1f)
				{
					warning.erase(warning.begin());
					warSize--;
				}
			}
			//DrawFormatString(200, 400, 0xffffff, "Size:%d", blSize);

			// �ǉ�
			if (blSize <= 45)
			{
				int Size = BlackLine.size();
				BlackLine.push_back(VECTOR3((10 * -Size), 0));
				blSize++;
			}
			if (warSize <= 5)
			{
				int wSize = warning.size();
				warning.push_back(VECTOR3((150 * (-wSize)), 0));
				warSize++;
			}
			lineCnt++;

			if (lineCnt % 2 == 0 && blackLine >= -15)
			{
				blackLine--;
			}
			for (int j = 0; j < BlackLine.size(); j++)
			{
				for (int i = 0; i < 5; i++)
				{
					DrawLine((BlackLine[j].x + i) + (blSize * 10), warningDown - 2, (BlackLine[j].x + i + 5) + (blSize * 10), (warningDown + blackLine), 0x000000, true);
				}
				BlackLine[j].x++;
				//DrawFormatString(200, 450, 0xffffff, "frontX :%f", BlackLine.begin()->x);

			}
			for (int k = 0; k < warning.size(); k++)
			{
				if ((warCnt++ / 150) % 2 == 0)
				{
					DrawRotaGraph((warning[k].x + 530)/* + (warSize * 150)*/, warning[k].y + 12, 0.7, 0, IMAGE_ID("image/warning!.png"), true);
				}
				//warning[k].x++;
				//push = warning[k].x;
			}
				
		}
		//DrawGraph(warningPosUp.x, warningPosUp.y, IMAGE_ID("image/warning!.png"), true);
	}

	lpGameTask.SetEnergy(energy);
	if (!lpGameTask.GetLandCheck())
	{
		distance = GameTask::GetInstance().distance;
	}
	else
	{
		distance = 300;
	}
	EofG = GameTask::GetInstance().gravity;
	gVec = GameTask::GetInstance().PandPvec;
	//DrawFormatString(10, 400, GetColor(255, 255, 255), "Angle:%ff", Angle);
	//DrawFormatString(10, 380, GetColor(255, 255, 255), "gvecX:%f gvecY:%f", gVec.x, gVec.y);*/
}

RECT  &Player::GetRect()
{
	return this->p;
}

VECTOR3 Player::Abstract(VECTOR3 i)
{
	return VECTOR3((i.x < 0 ? -0.5 : i.x == 0 ? 0 : 0.5),(i.y < 0 ? -0.5 : i.y == 0 ? 0 : 0.5));
}

VECTOR3 Player::OneVec(VECTOR3 vec)
{
	return VECTOR3(vec.x == 0 ? 0 : (vec.x < 0 ? -1 : 1), vec.y == 0 ? 0 : (vec.y < 0 ? -1 : 1));
}

bool Player::SetPos(VECTOR3 pos)
{
	this->pos = pos;
	return true;
}

const VECTOR3 & Player::GetPos(void)
{
	return this->pos;
}

const VECTOR3 & Player::GetVec(void)
{
	return vec;
}

bool Player::SetVec(VECTOR3 vec)
{
	this->vec = vec;
	return false;
}

bool Player::SetEnergy(float energy)
{
	this->energy = energy;

	return false;
}

VECTOR3 Player::AddVec(VECTOR3 pTop,VECTOR3 fTop)
{
	return this->vec = pTop + fTop;
}

const VECTOR3 & Player::GetplPos(void)
{
	return plPos;
}

bool Player::SetplPos(VECTOR3 pos)
{
	plPos = pos;
	return false;
}


void Player::SetMove(void)
{

	bool particleFlag = false;
	bool sideFlag = false;
	float particleCheck = 1.0f;
	// �P�ʃx�N�g��1
	//Obj::Normalize(gVec, distance);
	// �P�ʃx�N�g��2
	float a = abs(radianPos.x - pos.x);
	float b = abs(radianPos.y - pos.y);
	float vecMgn = sqrt((a * a) + (b * b));
	/////////////
	auto addVec = AddVec((Obj::Normalize((gVec), distance) * EofG), vec);// Obj::Normalize(vec, vecMgn));

	SetVec(addVec);
	plPos.x = pos.x;
	auto in = lpGameTask.GetScrollPos();
	lpGameTask.SetSclPosY(plPos.y);


	if (lpGameTask.setScrPos)
	{
		lpGameTask.pltrgScr = plPos;
		lpGameTask.setScrPos = false;
	}

	//DrawFormatString(10, 350, GetColor(255, 255, 255), "addVecX:%f addVecY:%f", addVec.x,addVec.y);
	if ((!lpGameTask.GetHitCheck()))
	{
		if ((plPos.y > playerPosMaxY && plPos.y < targetMax[lpGameTask.StageCnt].y))
		{
			plPos += lpGameTask.GetScrollPos();

			lpGameTask.plPosMaxFlag = false;
			lpGameTask.SetScrollPos(-(addVec * speed));
			posSwitch = 0;
		}
		else
		{
			lpGameTask.plPosMaxFlag = true;
			if ((posSwitch == 1 && pos.y <= posY_Max) || (posSwitch == 2 && pos.y >= posY_Max))
			{
				plPos += lpGameTask.GetScrollPos();

				lpGameTask.plPosMaxFlag = false;
				lpGameTask.SetScrollPos(-(addVec * speed));
			}
			else
			{
				pos.y += (addVec.y * speed);
			}
			if (plPos.y <= playerPosMaxY)
			{
				posSwitch = 1;
			}
			if (plPos.y > targetMax[lpGameTask.StageCnt].y)
			{
				posSwitch = 2;
			}

		}
		

		MaxFlag = false;
	}


	if (pos.y <= posMax.y - addVec.y)
	{
		MaxFlag = true;
		pos.x += addVec.x * speed;
	}
	else
	{
		pos.x += addVec.x *speed;
		MaxFlag = true;

	}
	SetPos(pos);

	DrawLine((int)radianPos.x, (int)radianPos.y, pos.x, pos.y, 0x0000ff, true);

	for (int i = 0; i < particleMax; i++)
	{
		if (particleList.size() > 0)
			particleTime[0][i]++;

		/*if (sideParticleList.size() > 0)
			particleTime[sideCheck][playerTime]++;*/

	}

	if (KeyMng::GetInstance().trgKey[P1_SPACE] && energy > 0)
	{
		//particleTime++;
		
		if (speed < speedMax)
		{
			speed += 3.0f;
		}
		energy -= 10;
		rolInc = 0;

		particleFlag = true;
		particleCheck = 5.0f;
		vec.x = sin(Angle);
		vec.y = -(cos(Angle));

	}
	else if (KeyMng::GetInstance().newKey[P1_SPACE] && energy > 0)
	{
		particleFlag = true;
		particleCheck = 5.0f;
		newPrePos = (radianPos - pos);
		newPrecount = count;
		newcount = count;
	}

	else if (KeyMng::GetInstance().newKey[P1_UP] && energy > 0)
	{
		if (speed < speedMax)
		{
			speed += 0.01f;
		}
		particleFlag = true;
		vec.x = sin(Angle);
		vec.y = -(cos(Angle));
		newPrePos = (radianPos - pos);
		newPrecount = count;
		energy -= 0.1f;
		//newcount = count;
		if (count != newcount)
		{
			if (count > newcount)
			{
				newcount += 0.01f;
			}
			else if (count < newcount)
			{
				newcount -= 0.01f;
			}
			else
			{

			}
		}

	}
	if (KeyMng::GetInstance().newKey[P1_DOWN] && energy > 0)
	{
		if (speed >= 0.05f)
		{
			speed -= 0.03f;
		}
	}
	

	VECTOR3 sideVec(radianPos - pos);

	// �p�x�ύX
	if (!lpGameTask.GetLandCheck())
	{
		if (KeyMng::GetInstance().newKey[P1_RIGHT])
		{
			rolInc += 0.0015f;
			count += 0.005f + rolInc;
			sideFlag = true;
			sideCheck = 1;
			newcount = newPrecount;
			lrFlag = 1;
		}
		else if (KeyMng::GetInstance().newKey[P1_LEFT])
		{
			rolInc -= 0.0015f;
			count -= 0.005f - rolInc;
			sideFlag = true;
			sideCheck = 2;
			newcount = newPrecount;
			lrFlag = -1;
		}
		else
		{
			if (lrFlag == 1)
			{
				count += 0.005f + rolInc;
			}
			else if (lrFlag == -1)
			{
				count -= 0.005f - rolInc;
			}
			else
			{

			}
			//sideFlag = false;
			sideCheck = 0;
			if (sideParticleList.size() > 0)
			{
				if (!(sideParticleList.empty()))
				{
					sideParticleList.pop_front();

				}
			}
		}
	}
	else
	{

	}

	if (speed > speedMax)
	{
		speed -= 0.1f;
	}

	if (particleFlag && !lpGameTask.GetLandCheck())
	{
		float parMax = (KeyMng::GetInstance().newKey[P1_SPACE] ? 2.0f : 2.9f);
		for (float f = 0.0f; f <parMax; f += 0.1f)
		{
			particle = AddObjlist(std::make_shared<Particle>(VECTOR3(pos.x, pos.y - (10 * vec.y)), (vec*f)*particleCheck, 0));
		}
	}
	if (sideFlag && !lpGameTask.GetLandCheck())
	{
		for (float f = 0.0f; f < 1.0f; f += 0.1f)
		{
			if (sidePos != turnPos)
			{
				sideParticleList.push_back(std::make_shared<Particle>(turnPos, /*OneVec*/(turnPos - sidePos) * 0.2f, sideCheck));
				sideParticle = sideParticleList.end();
				sideParticle--;
			}
		}
	}

	//�@�ݼ���߰è�ق̏���
	for (int i = 0; i < particleMax; i++)
	{
		if (particleList.size() > 0)
		{

			if (particleList.front()->GetTimer() > 12 || particleTime[0][0] > 12)
			{

 				if (!(particleList.empty()))
				{
					particleList.pop_front();

				}
			}
		}
		else
		{
			particleTime[0][i] = 0;
		}

		if (sideParticleList.size() > 0)
		{
			if (sideParticleList.front()->GetTimer() > 20)
			{
				if (!(sideParticleList.empty()))
				{
					sideParticleList.pop_front();
				}
			}
		}
		

	}
	if (sideParticleList.size() > 0)
	{
		//DrawFormatString(10, 600, 0xffffff, "%d", sideParticleList.front()->GetTimer());
	}
	/*DrawFormatString(10, 700, 0xffffff, "plPosX %f plPosY %f", plPos.x, plPos.y);
	DrawFormatString(10, 750, 0xffffff, "targetY %f plPosY %f", targetMax[0].y,pos.y);*/
}

std::list<particle_ptr>::iterator Player::AddObjlist(particle_ptr && objPtr)
{
	particleList.push_back(objPtr);
	auto itr = particleList.end();
	itr--;
	return itr;
}

