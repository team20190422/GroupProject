#pragma once
#include "Obj.h"
#include "KeyMng.h"
#include "GameTask.h"
#include <array>
#include <list>

typedef std::shared_ptr<Obj> particle_ptr;
typedef std::list<particle_ptr> particle_List;
typedef std::list<std::shared_ptr<Obj>> sideParticleList;

constexpr float speedMax = 0.5f;			// ��߰�ނ̍ő�l
constexpr unsigned int particleMax = 30;	// �߰è�ق̍ő�l
constexpr int playerPosMaxY = 30;			//�������̈ړ��̍ő�l
constexpr int ORBIT_MAX = 200;

class PlayerOrbit;
class Asteroid;
class UnivGravityCalc;

class Player :
	public Obj
{
public:
	Player(const int(&trgKey)[KEY_MAX], const int(&oldKey)[KEY_MAX]);

	Player(const int (&trgKey)[KEY_MAX], const int (&oldKey)[KEY_MAX], UnivGravityCalc& u);
	~Player();

	void Init();
	void Draw(void);
	void Update(void);

	VECTOR3 Abstract(VECTOR3 i);
	VECTOR3 OneVec(VECTOR3 vec);
	VECTOR3 AddVec(VECTOR3, VECTOR3);

	const VECTOR3& GetPos(void);
	const VECTOR3 & GetVec(void);
	const VECTOR3 & GetplPos(void);

	void SetAccel(VECTOR3)override;

	const VECTOR3 GetAccel();


	bool SetPos(VECTOR3 pos);
	bool SetVec(VECTOR3 vec);
	bool SetEnergy(float energy);
	bool SetplPos(VECTOR3 pos);

	RECT  &GetRect();
	RECT p;

	float energy = 100;

private:
	void SetMove(void);

	std::list<particle_ptr>::iterator AddObjlist(particle_ptr && objPtr);
	std::list<particle_ptr>::iterator particle;
	std::list<std::shared_ptr<Obj>>::iterator sideParticle;

	std::vector<VECTOR3> orbitPos[ORBIT_MAX];

	particle_List particleList;
	sideParticleList sideParticleList;

	std::vector<int> particleSizeMax = { 1,1,1 };
	std::vector<VECTOR3> BlackLine = { VECTOR3(10,0) };
	std::vector<VECTOR3> BlackLine1 = { VECTOR3(10,SCREEN_SIZE_Y) };
	std::vector<VECTOR3> warning = { VECTOR3(-150,0) };
	std::vector<VECTOR3> warning1 = { VECTOR3(-150,SCREEN_SIZE_Y) };
	std::vector<VECTOR3> targetMax = { VECTOR3(0,2500), VECTOR3(0,3000), VECTOR3(0,3500)};
	std::array<std::array<int, particleMax>, 3> particleTime = { 0 };	// �߰è�ق̕\������

	std::vector<std::shared_ptr<PlayerOrbit>>orbit;
	std::vector<std::shared_ptr<PlayerOrbit>>::iterator oItr;

	std::vector<std::shared_ptr<Asteroid>>ast;

	bp_List bpList;

	VECTOR3 posMax = { 0,600 };							// �[
	VECTOR3 pos = { (float)SCREEN_SIZE_X / 2, (float)SCREEN_SIZE_Y - (float)SCREEN_SIZE_Y / 3 };
	VECTOR3 size = { 64 / 2, 32 / 1 };
	VECTOR3 radianPos = { 0,0 };						// ��ڲ԰�̑O���̍��W
	VECTOR3 turnPos = { 0,0 };							// ��ڲ԰�̍��E�̍��W
	VECTOR3 sidePos = { 0,0 };
	VECTOR3 vec = { 0,-1 };								// ��ڲ԰���޸��
	VECTOR3 gVec = { 0,0 };								// �d��
	VECTOR3 PreVec = { 0,0 };
	VECTOR3 plPos = { 0,0 };
	VECTOR3 warningPosUp = { -450,0 };
	VECTOR3 warningPosDw = { -450,0 };
	VECTOR3 newPos = { 0,0 };
	VECTOR3 newPrePos = { 0,0 };
	VECTOR3 linePos = { 0.0f,0.0f };
	VECTOR3 mWheelRoll = { 0.0f,0.0f };
	VECTOR3 DofT = { 0.0f,0.0f };						// ��ڲ԰�̐i�s�����޸��
	VECTOR3 finalVec = { 0,0 };
	VECTOR3 accel = { 0.0f ,0.0f };
	VECTOR3 setA = { 0.0f ,0.0f };

	VECTOR3 posB = { 0,0 };
	VECTOR3 vecA = { 0,0 };

	float speedA = 0.0f;
 
	float count = -3.0f;								//�@�O�����W�̵̾��
	float rolInc = 0.0f;
	float Size = 1.0f;									// ����
	float Angle = 0;									// ��]�p�x
	float speed = 0.5f;									// ��߰��
	float distance;										// ��ڲ԰����f���܂ł̋����̑傫��
	float EofG = 1.5f;									// �d�͂̉e��
	float newPrecount = -3.0f;
	float newcount = -3.0f;
	float PreAngle;
	float PreAngle2;
	float v = 0.0f;
	float mgn = 0.0f;

	float orbitDistance = 0.0f;
	float alpha = 255.0f;

	int lrFlag = 0;
	int sideCheck = 0;									// ���E���߰è�ق�����
	int landingTime = 0;
	int warningDown = 0;
	int warningUp = 0;
	int blackLine = 0;
	int blackLine1 = 0;
	int lineCnt = 0;
	int blSize = 0;
	int blSize1 = 0;
	int warSize = 0;
	int warSize1 = 0;
	int push = 0;
	int warCnt = 0;
	int posSwitch = 0;
	int mWheel = 0;
	int shakeCnt = 0;
	int shake = 0;
	int orbitSize = 0;
	int orbitCount = 0;
	int font;
	int font1 = 0;
	struct {
		int x;
		int y;
	}Mouse;

	bool MaxFlag = false;
	bool WarningDownFlag = false;
	bool lineFlag = false;
	bool dbMode = false;
	bool shakeFlag = false;
	bool orbitFlag;

	UnivGravityCalc& univ;
};

