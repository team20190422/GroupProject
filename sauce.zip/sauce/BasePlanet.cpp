#include <DxLib.h>
#include <math.h>
#include "GameTask.h"
#include "BasePlanet.h"

constexpr int PLAYER_SIZE_X = 32;
constexpr int PLAYER_SIZE_Y = 32;

BasePlanet::BasePlanet():Obj(j,j)
{
}

BasePlanet::~BasePlanet()
{
}

void BasePlanet::Update()
{
}

float BasePlanet::UnivGravity(float M, float m, float r)
{
	float G = 1.0f;		// ���L���͒萔
	return G * M * m / r * r;
}

int BasePlanet::GetRadius(int image)
{
	GetGraphSize(image, &width, &hight);
	return width / 2;
}

void BasePlanet::Draw()
{
	
}

const float & BasePlanet::GetDistance()
{
	return this->distance;
}

const float & BasePlanet::GetGravity()
{
	return this->gravity;
}

const float & BasePlanet::GetOrbitDistance()
{
	return this->orbitDistance;
}

const VECTOR3 & BasePlanet::GetVec()
{
	auto planetAngle = atan2(planetPosC.y - playerPosC.y, planetPosC.x - playerPosC.x) + 1.5f;
	VECTOR3 planetVec = { 0,0 };

	planetVec.x = sin(planetAngle);
	planetVec.y = -cos(planetAngle);
	
	GameTask::GetInstance().SetPlanetPos(planetPosC);
	return planetVec;
}

const VECTOR3 & BasePlanet::GetPos()
{
	return this->pos;
}


