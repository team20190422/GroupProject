#include "DxLib.h"
#include "GameTask.h"
#include "ImageMng.h"
#include "Tutorial.h"

constexpr int PI = 3.1415;

Tutorial::Tutorial()
{
	Init();
}

Tutorial::~Tutorial()
{
}

void Tutorial::Init()
{
	alpha = 255;
	count = 0;
	keyAlpha = 255.0f;
	tipsAlpha = 0.0f;
}

void Tutorial::Draw()
{
	// Xbox�R���p
	//DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 1, 0, ImageMng::GetInstance().SetID("image/Xbox.png"), true);
	//if (((count / 40) % 2) == 0)
	//{
	//	DrawString(SCREEN_SIZE_X / 2 - 100, 650, "Press '�P�b�e�C'button!", 0xffffff);
	//}

	// �L�[�{�[�h�p
	//if (lpGameTask.GetLandingCnt(0) >= 255)
	{
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, tipsAlpha);
		DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 1.0, 0, ImageMng::GetInstance().SetID("image/tutorial2.png"), true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND,0);

		SetDrawBlendMode(DX_BLENDMODE_ALPHA, keyAlpha);
		DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 1.0, 0, ImageMng::GetInstance().SetID("image/key.png"), true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND,0);
	}

	if (((count / 40) % 2) == 0)
	{
		DrawString(SCREEN_SIZE_X / 2 - 125, 725, "Press the 'SPACE KEY'!", 0xffffff);
	}
	//SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
	//DrawFormatString(50, 100, 0xffffff, "%d", alpha);
	/*DrawString(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, "tutorial", 0xffffff);*/
}

void Tutorial::Update()
{
	count++;
	//if (lpGameTask.GetLandingCnt(0) >= 255)
	{
		if (lpGameTask.tipsFlag)
		{
			if (tipsAlpha < 255)
			{
				tipsAlpha += 2.0f;
			}
			if (keyAlpha > 0)
			{
				keyAlpha -= 2.0f;
			}
		}
	}
	//alpha = sin(PI * 2 / 20 * count) * 128;
}
