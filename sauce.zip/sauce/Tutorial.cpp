#include "DxLib.h"
#include "GameTask.h"
#include "ImageMng.h"
#include "Tutorial.h"

Tutorial::Tutorial()
{
}

Tutorial::~Tutorial()
{
}

void Tutorial::Draw()
{
	DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 1, 0, ImageMng::GetInstance().SetID("image/phone.png"), true);
	DrawString(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, "tutorial", 0xffffff);
}

void Tutorial::Update()
{
}
