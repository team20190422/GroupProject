#include "DxLib.h"
#include "GameTask.h"
#include "ImageMng.h"
#include "Tutorial.h"

constexpr int PI = 3.1415;

Tutorial::Tutorial()
{
}

Tutorial::~Tutorial()
{
}

void Tutorial::Draw()
{
	DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 1, 0, ImageMng::GetInstance().SetID("image/key.png"), true);
	//SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
	if (((count / 40) % 2) == 0)
	{
		DrawString(SCREEN_SIZE_X / 2 - 80, 700, "Press SpaceKey!", 0xffffff);
	}
	//SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
	DrawFormatString(50, 100, 0xffffff, "%d", alpha);
	/*DrawString(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, "tutorial", 0xffffff);*/
}

void Tutorial::Update()
{
	count++;
	//alpha = sin(PI * 2 / 20 * count) * 128;

}
