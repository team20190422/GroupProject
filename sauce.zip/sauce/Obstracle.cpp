#include "Obstracle.h"
#include "GameTask.h"
#include "ImageMng.h"




Obstracle::Obstracle()
{
	pos = { (float)SCREEN_SIZE_X / 2,(float)SCREEN_SIZE_Y};
	speed = 5.0f;
	o.left = (long)(pos.x - size.x / 2);
	o.right = (long)(pos.x + size.x / 2);
	o.top = (long)(pos.y - size.y / 2);
	o.bottom = (long)(pos.y + size.y / 2);

}


Obstracle::~Obstracle()
{
}

void Obstracle::Update()
{
	SetMove();
	//��`�̃T�C�Y��ݒ�(��Q��)
	int o_width = o.right - o.left;
	int o_height = o.bottom - o.top;
	if (!lpGameTask.GetDB())
	{
		SetRect(&o, pos.x - size.x / 2, pos.y - size.y / 2, pos.x + o_width / 2, pos.y + o_height / 2);
	}
	//��`�̃T�C�Y��`��(�f�o�b�O�p)
	//DrawBox(o.left,o.top, o.right, o.bottom, GetColor(255, 0, 0), false);
	//DrawFormatString(10, 40, GetColor(255, 255, 255), "posX�@%f  posY %f", pos.x, pos.y);

	planetPos.resize(lpGameTask.planetMax);
	planetGravity.resize(lpGameTask.planetMax);
	distanceMin = 10000.0f;
	for (int i = 0; i < lpGameTask.planetMax; i++)
	{
		planetPos[i] = lpGameTask.GetPlanetPositon(i);
		planetGravity[i] = lpGameTask.GetPlanetGravity(i);

		float a = abs(planetPos[i].x - pos.x);
		float b = abs(planetPos[i].y - pos.y);
		distance = sqrt((a * a) + (b * b));
		if (distance < distanceMin)
		{
			distanceMin = distance;
			planetPosSave = planetPos[i];
			saveGravity = planetGravity[i];
		}
	}
	auto angle = atan2(planetPosSave.x - pos.x, planetPosSave.y - pos.y);
	gVec.x = sin(angle);
	gVec.y = -cos(angle);
	EofG = saveGravity;
	//DrawFormatString(20, SCREEN_SIZE_Y / 2 + 20, 0xffffff, "Gravity:%f", EofG);
	addVec = (Obj::Normalize(gVec, distanceMin) * EofG) + vec;
	test = (Obj::Normalize(gVec, distanceMin) * EofG);
	DrawFormatString(50, SCREEN_SIZE_Y / 2, 0xffffff, "addVec.x:%.3f,addVec.y:%.3f", addVec.x, addVec.y);
	DrawFormatString(50, SCREEN_SIZE_Y / 2 + 15, 0xffffff, "EofG.x:%.3f", EofG);
	DrawFormatString(50, SCREEN_SIZE_Y / 2 + 30, 0xffffff, "vec.x:%.3f,vec.y:%.3f", vec.x, vec.y);
	//DrawFormatString(50, SCREEN_SIZE_Y / 2, 0xffffff, "X:%f,Y:%f", test.x,test.y);
	//SetVector(addVec);
}

void Obstracle::Draw()
{
	DrawGraph(pos.x - size.x/2, pos.y - size.y/2, IMAGE_ID(imageName),true);
	DrawLine(pos.x, pos.y, planetPosSave.x, planetPosSave.y, 0xffff00, true);
	//DrawLine(pos.x, pos.y - SCREEN_SIZE_Y, pos.x, pos.y+ SCREEN_SIZE_Y, GetColor(255, 255, 255), true);
}

void Obstracle::SetMove()
{
	pos.y += speed;
	fPos.x = pos.x;
	fPos.y = pos.y + 100;
	vec = { fPos.x - pos.x,fPos.y - pos.y };
	DrawLine(fPos.x, fPos.y, pos.x, pos.y, 0xffffff, true);
	if (pos.y > SCREEN_SIZE_Y) {
		pos.y = SCREEN_SIZE_Y - SCREEN_SIZE_Y;
		pos.x = GetRand(SCREEN_SIZE_X);
	}
}

bool Obstracle::SetPos(VECTOR3 pos)
{
	this->pos = pos;
	return false;
}

RECT  &Obstracle::GetRect()
{
	return this->o;
}
