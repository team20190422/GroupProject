#include "Asteroid.h"
#include "Obstracle.h"
#include "PlayerOrbit.h"
#include "GameTask.h"


constexpr int OBST_SIZE = 25;

std::vector<VECTOR3> Asteroid::PtoPVector;
std::vector<float> Asteroid::distance;

Asteroid::Asteroid(VECTOR3 pos, int AstCnt)
{
	mPos = pos;
 	animNum = (AstCnt % 3);
	astCount = AstCnt;
	Init();
}


Asteroid::~Asteroid()
{
}

const VECTOR3 & Asteroid::GetPos(void)
{
	return pos;
}

bool Asteroid::SetPos(VECTOR3 pos)
{
	this->pos = pos;
	return false;
}

void Asteroid::Init(void)
{
	asteroidSize = 2.0;
	pos = mPos;

	AsteroidImage[0] = LoadGraph("image/asteroid01.png");
	AsteroidImage[1] = LoadGraph("image/asteroid02.png");
	AsteroidImage[2] = LoadGraph("image/asteroid03.png");

	planetImage[0] = LoadSoftImage("image/asteroid01.png");
	planetImage[1] = LoadSoftImage("image/asteroid02.png");
	planetImage[2] = LoadSoftImage("image/asteroid03.png");

	for (int i = 0; i < 3; i++)
	{
		lpGameTask.SetSoftImg(i, planetImage[i]);
	}
	Size = (float)BasePlanet::GetRadius(AsteroidImage[animNum])* ((float)asteroidSize / 2);

}

void Asteroid::Update(void)
{
	//DrawFormatString(10, 450, 0xffffff, "time %d", nTime);

	unsigned int rSize = (PLAYER_SIZE / 2);
	VECTOR3 playerPosR(lpGameTask.playerPos.x + rSize, lpGameTask.playerPos.y + rSize);
	VECTOR3 playerPosL(lpGameTask.playerPos.x - rSize, lpGameTask.playerPos.y - rSize);
	VECTOR3 radianPos(pos.x + (r * cos(1 / 2)), pos.y + (r * sin(1 / 2)));

	unsigned int meteoHarf = (OBST_SIZE / 2);
	VECTOR3 obstPosR(lpGameTask.GetObstPos().x + meteoHarf, lpGameTask.GetObstPos().y + meteoHarf);
	VECTOR3 obstPosL(lpGameTask.GetObstPos().x - meteoHarf, lpGameTask.GetObstPos().y - meteoHarf);
	//VECTOR3 radianPos(pos.x + (r * cos(1 / 2)), pos.y + (r * sin(1 / 2)));


	lpGameTask.targetSize = r;
	lpGameTask.targetPos = radianPos;
	lpGameTask.targetVec = (radianPos - pos);

	if (!lpGameTask.GetHitCheck() && !lpGameTask.GetLandCheck())
	{
		if (!lpGameTask.plPosMaxFlag)
		{
			pos = pos + lpGameTask.GetScrollPos();
		}
	}

	int r = 0, g = 0, b = 0, a = 0;
	if (!lpGameTask.GetDB())
	{
		for (int x = 0; x < IMG_SIZE; x++)
		{
			for (int y = 0; y < IMG_SIZE; y++)
			{
				GetPixelSoftImage(planetImage[animNum], x, y, &r, &g, &b, &a);

				if (a > 0)
				{
					VECTOR3 asteroidPosL((pos.x - IMG_SIZE) + (x * asteroidSize), (pos.y - IMG_SIZE) + (y * asteroidSize));
					VECTOR3 asteroidPosR((pos.x - IMG_SIZE) + (x + 2) * asteroidSize, (pos.y - IMG_SIZE) + (y + 2) * asteroidSize);

					//DrawBox(asteroidPosL.x, asteroidPosL.y, asteroidPosR.x, asteroidPosR.y, GetColor(255, 0, 0), true);
					if (asteroidPosR.x > playerPosL.x && asteroidPosL.x < playerPosR.x)
					{
						if (asteroidPosR.y > playerPosL.y && asteroidPosL.y < playerPosR.y)
						{
							lpGameTask.SetHitCheck(true);
						}
					}

					if (asteroidPosR.x > obstPosL.x && asteroidPosL.x < obstPosR.x)
					{
						if (asteroidPosR.y > obstPosL.y && asteroidPosL.y < obstPosR.y)
						{
							lpGameTask.SetHitObstAst(true);
						}
					}
				}
			}
		}
	}

	lpGameTask.SetAnimNum(animNum);
	lpGameTask.SetAstPos(astCount - 1, pos);

	//DrawLine(lpGameTask.playerPos.x, lpGameTask.playerPos.y, pos.x, pos.y, 0xffffff, true);

	PtoP = lpGameTask.GetPlanetToPlayerVectorCalc(pos, lpGameTask.playerPos);
	PtoPVector.resize(lpGameTask.planetMax);
	PtoPVector[astCount - 1] = PtoP;
	dist = sqrt((PtoP.x * PtoP.x) + (PtoP.y * PtoP.y));
	distance.resize(lpGameTask.planetMax);
	distance[astCount - 1] = dist;
	univG.resize(lpGameTask.planetMax);
	univG[astCount - 1] = UnivGravity(mass, PLAYER_MASS, dist);

	lpGameTask.SetPlanetGravity(astCount - 1, univG[astCount - 1]);
	lpGameTask.SetPlanetToPlayerVector(astCount - 1,PtoPVector[astCount - 1]);
	lpGameTask.SetPlanetToPlayerDistance(astCount - 1, dist);
	//DrawFormatString(50, 300 + 15 * astCount - 1, 0xff0000, "%f %f", lpGameTask.GetPlanetToPlayerVector(astCount - 1).x, lpGameTask.GetPlanetToPlayerVector(astCount - 1).y);
	//DrawFormatString(50, 300 + 15 * astCount - 1, 0xff0000, "%f", lpGameTask.GetPlanetToPlayerDistance(astCount - 1));
}

void Asteroid::Draw(void)
{
	DrawRotaGraphF(pos.x, pos.y, asteroidSize, 0, AsteroidImage[animNum], true);
}

