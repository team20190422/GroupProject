#pragma once
#include "BasePlanet.h"

constexpr int ImageMax = 3;
class UnivGravityCalc;
class Asteroid :
	public BasePlanet
{
public:
	Asteroid(VECTOR3 pos, int AstCnt,UnivGravityCalc& u);
	~Asteroid();

	const VECTOR3 & GetPos(void);
	bool SetPos(VECTOR3 pos);

private:
	VECTOR3 mPos = { 0,0 };

	double asteroidSize = 3.0;
	float Size = 0;
	float gravity = 1.3f;
	float mass = 3000.0f;
	int AsteroidImage[ImageMax] = { 0 };
	int planetImage[ImageMax] = { 0 };
	int animNum = 0;
	int nTime = 0;
	int astCount = 0;
	int c[10] = { 0 };
	static std::vector<float>distance;		// PtoP�i�[�p

	UnivGravityCalc& univ;

protected:
	void Init(void);
	void Update(void);
	void Draw(void);

};

