#pragma once
#include "BasePlanet.h"

class UnivGravityCalc;

constexpr unsigned int EarthMax = 20;
class Earth :
	public BasePlanet
{
public:
	Earth(VECTOR3 pos,UnivGravityCalc& u);
	~Earth();

	const VECTOR3 & GetPos(void);
	bool SetPos(VECTOR3 pos);


private:
	VECTOR3 mPos = { 0,0 };

	double earthSize = 3.0;
	float Size = 0;
	int EarthImage[EarthMax] = { 0 };
	int planetImage = 0;
	int earthCnt = 0;
	int animCnt = 0;
	float gravity = 2.0f;
	float mass = 7000.0f;

	UnivGravityCalc& univ;

protected:
	void Init(void);
	void Update(void);
	void Draw(void);
};

