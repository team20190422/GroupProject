#pragma once
#include "VECTOR3.h"
#include "Obj.h"
class Obstracle :
	public Obj
{
public:
	Obstracle();
	~Obstracle();
	void Update();
	void Draw();
	void SetMove();

	bool SetPos(VECTOR3 pos);
	RECT  &GetRect();
	RECT o;
private:
	std::vector<VECTOR3>planetPos;
	std::vector<float>planetGravity;

	float speed;
	float distanceMin = 10000.0f;
	float EofG = 0.0f;
	float saveGravity = 0.0f;

	VECTOR3 pos = { 0.0f,0.0f };
	VECTOR3 fPos = { 0.0f,0.0f };
	VECTOR3 size = { 64 / 2 , 32 / 1 };
	VECTOR3 vec = { 0.0f,0.0f };
	VECTOR3 gVec = { 0.0f,0.0f };
	VECTOR3 addVec = { 0.0f,0.0f };
	VECTOR3 test = { 0.0f,0.0f };
	VECTOR3 planetPosSave = { 0.0f,0.0f };
};

