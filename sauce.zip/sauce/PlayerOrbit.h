#pragma once
#include <vector>
#include "Player.h"

class OrbitPoint;
class UnivGravityCalc;

class PlayerOrbit :public Player
{

public:
	PlayerOrbit(const VECTOR3&, const VECTOR3&, const float&, const VECTOR3& accel, UnivGravityCalc& u);
	~PlayerOrbit();

	const VECTOR3& GetVec1(void);
	void SetVec1(VECTOR3 vec);

	const float& GetOrbDistance(void);
	void SetOrbDistance(float dis);

	void SetVector(VECTOR3);
	void SetPosition(VECTOR3);
	void SetSpeed(float);
	void SetSpeedV(float);

	const bool& GetOrbitRemove();
	void SetOrbitRemove(bool);

	std::vector<VECTOR3>planetPos;
	std::vector<float>planetGravity;

	std::vector<std::shared_ptr<OrbitPoint>>point;
	std::vector<std::shared_ptr<OrbitPoint>>::iterator pItr;
	std::vector<VECTOR3>pointPosition;

	void Update();
	void Draw();
	void SetMove();

	float distance = 1000.0f;
	float orbDistance = 0.0f;

	int anim = 0;

	bool flag = false;

private:
	const int(&trgKey)[KEY_MAX] = { 0 };
	const int(&oldKey)[KEY_MAX] = { 0 };

	int count = 0;

	float speed = 0.0f;
	VECTOR3 speedV = { 0.0f ,0.0f };
	float mgn = 0.0f;
	float v = 0.0f;
	float distanceMin = 10000.0f;
	float EofG = 0.0f;
	float saveGravity = 0.0f;

	VECTOR3 planetPosSave = { 0.0f,0.0f };
	
	VECTOR3 DofT = { 0.0f,0.0f };
	VECTOR3 pos = { 0.0f,0.0f };
	VECTOR3 fPos = { 0.0f,0.0f };				// �ŏI���W
	VECTOR3 vec = { 0.0f,0.0f };
	VECTOR3 addVec = { 0.0f,0.0f };
	VECTOR3 dir = { 0.0f,0.0f };
	VECTOR3 uniVec = { 0.0f,0.0f };
	VECTOR3 vector = { 0.0f,0.0f };
	VECTOR3 gVec = { 0.0f,0.0f };
	VECTOR3 test = { 0.0f ,0.0f };
	VECTOR3 finalVec = { 0,0 };
	VECTOR3 univGrav = { 0.0f,0.0f };
	VECTOR3 orbitAccel = { 0.0f,0.0f };

	bool orbitRemove = false;
	bool hitFlag = false;

	float speedA = 0.0f;

	UnivGravityCalc& univ;
};