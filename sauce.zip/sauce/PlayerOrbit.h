#pragma once
#include "Player.h"

class PlayerOrbit :public Player
{

public:
	PlayerOrbit(const VECTOR3&, const VECTOR3&);
	~PlayerOrbit();

	const VECTOR3& GetVec1(void);
	void SetVec1(VECTOR3 vec);

	void Update();
	void Draw();
	void SetMove();
private:
	const int(&trgKey)[KEY_MAX] = { 0 };
	const int(&oldKey)[KEY_MAX] = { 0 };

	float speed = 2.0f;
	float mgn = 0.0f;
	
	VECTOR3 DofT = { 0.0f,0.0f };
	VECTOR3 pos = { 0.0f,0.0f };
	VECTOR3 vec = { 0.0f,0.0f };
	VECTOR3 dir = { 0.0f,0.0f };
	VECTOR3 uniVec = { 0.0f,0.0f };
	VECTOR3 vector = { 0.0f,0.0f };
};