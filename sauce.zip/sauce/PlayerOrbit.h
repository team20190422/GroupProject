#pragma once
#include "Player.h"

class PlayerOrbit :public Player
{

public:
	PlayerOrbit(const VECTOR3&, const VECTOR3&, const float&);
	~PlayerOrbit();

	void Update();
	void Draw();
	void SetMove();
private:
	const int(&trgKey)[KEY_MAX] = { 0 };
	const int(&oldKey)[KEY_MAX] = { 0 };

	float speed = 2.0f;
	
	float vx = 0;
	
	
	VECTOR3 DofT = { 0.0f,0.0f };
	VECTOR3 pos = { 0.0f,0.0f };
	VECTOR3 vec = { 0.0f,0.0f };
	VECTOR3 dir = { 0.0f,0.0f };
};