#pragma once
#include "VECTOR3.h"
#include <vector>
#include <array>

constexpr unsigned int stageMax = 3;

// ���
std::vector<VECTOR3> planetSet = {
	// �A��
	//VECTOR3(280, 1300) ,
	//VECTOR3(50, 1200) ,
	VECTOR3(100, 900) ,
	VECTOR3(200, 800) ,

	// �s��
	VECTOR3(400, 300) ,
	VECTOR3(100, -300) ,
	VECTOR3(400, -600),
	VECTOR3(130,-800),
	//VECTOR3(120,-1000),
	VECTOR3(20,-1300),
	VECTOR3(400, -1500) ,
	//VECTOR3(370, -1800) ,
	VECTOR3(110, -2100) ,
	VECTOR3(150,-50) ,
	VECTOR3(10,-2000),
};

// ���
std::vector<VECTOR3> planetSet2 = { 
	// �A��
	//VECTOR3(50, 1300) ,
	//VECTOR3(350, 1400) ,
	VECTOR3(400, -2700) ,
	VECTOR3(350, -2500) ,
	VECTOR3(100,-2400),
	VECTOR3(400, -2200) ,

	VECTOR3(420, -2000) ,
	VECTOR3(200, -1750),

	VECTOR3(100,-1500),
	VECTOR3(400, -1350) ,

	VECTOR3(200, -1250),

	VECTOR3(325, -1000) ,
	VECTOR3(300, -750),
	VECTOR3(270, -600) ,

	VECTOR3(200, -500) ,
	VECTOR3(350, -250) ,
	VECTOR3(400, -100),

	VECTOR3(25,50),
	VECTOR3(250, 150),
	VECTOR3(100, 300) ,
	VECTOR3(450,500),
	VECTOR3(200,800),
	VECTOR3(350,1000),
	//VECTOR3(250,-1200),
	//VECTOR3(300,-1400),
	////VECTOR3(300,-900),
	//VECTOR3(200,-1600),
	//VECTOR3(300,-1800),

	////VECTOR3(250,-950),
	//VECTOR3(400,-1100),
};

// �O��
std::vector<VECTOR3> planetSet3 = {
	// �A��
	//VECTOR3(200, 1400) ,
	//VECTOR3(50, 1350) ,
	//VECTOR3(340, 1300) ,
	//VECTOR3(150, 1200) ,
	VECTOR3(400, 1000) ,
	VECTOR3(80, 930) ,
	VECTOR3(250, 850) ,
	VECTOR3(400, 780) ,

	// �s��
	VECTOR3(210, 300) ,
	VECTOR3(50, 200) ,
	VECTOR3(400, 90) ,
	VECTOR3(150, 0) ,
	VECTOR3(300,-100),
	VECTOR3(200,-300),
	VECTOR3(50,-500),
	VECTOR3(300,-700),
	VECTOR3(190,-900),
	VECTOR3(40,-1200),
	VECTOR3(300,-1400),
	VECTOR3(100,-1800),
	VECTOR3(230,-2000)
};


std::vector<VECTOR3> stageSet[] = { planetSet,planetSet2,planetSet3};
std::vector<VECTOR3> targetSet = { VECTOR3(50, -1500),VECTOR3(50, -2000), VECTOR3(150,-2500) };
std::vector<VECTOR3> tSetPos;

