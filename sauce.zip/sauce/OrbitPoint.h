#pragma once
#include "DxLib.h"
#include "PlayerOrbit.h"

class OrbitPoint : public PlayerOrbit
{
public:
	OrbitPoint(const VECTOR3& vec,const VECTOR3& pos, const float& v);
	~OrbitPoint();
	void SetPointPos(VECTOR3);
	void Update();
	void Draw();
private:
	VECTOR3 pos = { 0.0f,0.0f };
	VECTOR3 savePos = { 0.0f,0.0f };

	float alpha = 255;
};