#pragma once
#include "PlayerOrbit.h"

class OrbitPoint : public PlayerOrbit
{
public:
	OrbitPoint(const VECTOR3& vec,const VECTOR3& pos, const float& v);
	~OrbitPoint();
	void Update();
	void Draw();
private:
	VECTOR3 pos = { 0.0f,0.0f };
};