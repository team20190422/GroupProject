#pragma once
#include "DxLib.h"
#include "PlayerOrbit.h"

class OrbitPoint : public PlayerOrbit
{
public:
	OrbitPoint(const VECTOR3& vec,const VECTOR3& pos, const float& v,const int& cnt);
	~OrbitPoint();
	void SetPointPos(VECTOR3 , int i);
	const VECTOR3& GetPointPos();

	void SetRemove(bool);
	const bool& GetRemove();

	void Update();
	void Draw();
private:
	VECTOR3 pos = { 0.0f,0.0f };
	VECTOR3 savePos = { 0.0f,0.0f };

	std::vector<VECTOR3>pointPos;

	float alpha = 255;
	
	int size = 0;

	bool remove = false;
};