#include "LandPlayer.h"
#include "ImageMng.h"
#include "Particle.h"

constexpr float PI = 3.1415f;
constexpr int SPC_SIZE_X = 40;
constexpr int SPC_SIZE_Y = 28;

LandPlayer::LandPlayer(const int(&trgKey)[KEY_MAX], const int(&oldKey)[KEY_MAX] ,int stageCnt) :Obj(trgKey, oldKey)
{
	Init();
	motherPos = { (float)SCREEN_SIZE_X / 2,  -20 };
	LoadDivGraph("image/capsuleParaAnim.png", 10, 10, 1, 15, 30, capsulePara, true);
	for (int j = 0; j < 11; j++)
	{
		DieAnim[j] = LoadDivGraph("image/Explosion/����_��.png", 11, 11, 1, 115, 100, DieAnim, true);
	}
	BG = LoadGraph("image/landBG.png");
	mapSoft = (lpGameTask.StageCnt == 0 ? LoadSoftImage("image/landMap01.png") : (lpGameTask.StageCnt == 1 ? LoadSoftImage("image/landMap2-01.png") : LoadSoftImage("image/landMap3-01.png")));
	pos = { 50,-500 };
	GameLight = 255;
	this->stageCnt = stageCnt;

	Fadeout[0] = { 0 };
	Fadeout[1] = { 0 };
	Fadeout[2] = { 0 };
}


LandPlayer::~LandPlayer()
{
}

void LandPlayer::Init(void)
{
	SetFontSize(20);
	sinFlag = false;
	injectionFlag = false;
	shieldFlag = true;
	separateFlag = false;
	skipFlag = false;
	particleFlag = false;
	lFlag = false;

	parListFlag = { 0 };
	Fadeout = { 0 };

	count = 0;
	colCnt = 1;
	colTmp = 200;
	colTmp2 = 200;
	cupsule = 0;
	planet = 0;
	capsuleShield = 0;
	spCraft = 0;
	landMap = 0;
	mapSoft = 0;
	suiheikei[0] = { 0 };
	suiheikei[1] = { 0 };
	capsuleParaL = 0;
	color = 0;
	colorPos = 0;
	animCnt = 0;
	anim = 0;
	tmp;
	RGB[0] = 154;
	RGB[1] = 96;
	RGB[2] = 61 + 30;
	lrFlag = 0;										// -1:����] 0:�����l 1:�E��]			
	speedUI = 0;
	BG = 0;
	skipCnt = 0;
	scene = 0;
	offset = 0;
	stop = 1;
	landAngle = 0;									// -1:���s 0:�����l 1:����
	deg = 0;
	sepCnt = 0;
	AnimCnt = 0;									// ""
	AnimTime = 0;									// ""
	GameLight = 255;								// �Ó]����
	stageCnt = 0;									// ���݂̽ð�ފm�F
	distance = 800;									// ����
	smokeTime = 0;
	blinkCnt = 0;
	alphaChaku = 0;
	font1 = 0;

	countF = 0.0f;
	size = 4.0f;
	vx = 0.0f;
	vy = 0.0f;
	vySkip = 0.0f;
	angle = 0.0f;
	shieldAngle = 0.0f;
	paraAngle = 0.0f;
	spCAngle = 0.0f;
	spCAngleF = 0.0f;								// spaceCraft�̍ŏI�p�x
	spCSize = 1.4f;
	rolInc = 0.0f;
	speed = 0.0f;
	mapSize = 3.0f;
	particleSpeed = 3.0f;
	alpha = 0.0f;
	landAlpha = 255.0f;
	landingDiv = 0.0f;
	landPointAlpha = { 255,255, 255, 255, 255 };

	cineBox1.l = 0;
	cineBox1.r = 450;
	cineBox1.u = 0;
	cineBox1.d = 0;

	cineBox2.l = 0;
	cineBox2.r = 450;
	cineBox2.u = 800;
	cineBox2.d = 800;

	cupPos = { 0,0 };
	shieldPos = { 0,0 };
	paraPos = { SCREEN_SIZE_X / 2, -100 };
	mapImageSize = { 150,266 };
	hitPos = { 0,0 };

	centerPosU = { 0,0 };
	centerPosD = { 0,0 };

	spCLine1U = { 0,0 };
	spCLine2U = { 0,0 };

	spCLine1D = { 0,0 };
	spCLine2D = { 0,0 };
	landingL = { 0,0 };
	landingR = { 0,0 };
}

void LandPlayer::Draw(void)
{
	lpGameTask.SetStageCnt(stageCnt);
	DrawGraph(0, 0, BG, true);
	if (lpGameTask.darkFlag == false)
	{
		auto stageGet = lpGameTask.GetStageCnt();
		if (lpGameTask.GetStageCnt() == 0)
		{
			color = GetColor(114, 56, 36);
			color = GetColor(114, 56, 36);
		}
		else if (lpGameTask.GetStageCnt() == 1)
		{
			color = GetColor(226, 151, 0);
		}
		else
		{
			color = GetColor(18, 86, 153);
		}
		DrawCircle(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y, 500, color, true);
		if (injectionFlag == true)
		{
			DrawRotaGraphF(cupPos.x, cupPos.y, size, 0, ImageMng::GetInstance().SetID("image/capsule.png"), true);
			lpGameTask.SetCupSize(size);

			if (size < 1.5f)
			{
				SetDrawBright(100 + smokeTime, smokeTime < 165 ? smokeTime : 165, 0);
				SetDrawBlendMode(DX_BLENDMODE_ALPHA, smokeTime += 2);
				DrawRotaGraphF(cupPos.x, cupPos.y, size * 0.4f, 0, ImageMng::GetInstance().SetID("image/��.png"), true);
				SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
				SetDrawBright(255, 255, 255);
			}
		}
		else
		{
		}
		
		DrawRotaGraphF(motherPos.x, motherPos.y, 2, 0, IMAGE_ID(imageName), true);
		//DrawFormatString(SCREEN_SIZE_X - 100, SCREEN_SIZE_Y / 2, 0xffffff, "%d", GetFontSize());
	}
	else
	{
		if (!shieldFlag && lpGameTask.darkFlag == true && !lpGameTask.GetDarkFlag2())
		{
			//for (int i = 1; i < SCREEN_SIZE_Y; i++)
			//{
			//	if (i % colTmp == 0)
			//	{
			//		RGB[0];
			//		RGB[1];
			//		RGB[2] -= 30;
			//		if (RGB[0] >= 255)
			//			RGB[0] = 255;
			//		else if (RGB[0] <= 0)
			//			RGB[0] = 0;

			//		if (RGB[1] >= 255)
			//			RGB[1] = 255;
			//		else if (RGB[1] <= 0)
			//			RGB[1] = 0;

			//		if (RGB[2] >= 255)
			//			RGB[2] = 255;
			//		else if (RGB[2] <= 0)
			//			RGB[2] = 0;

			//		colTmp2 /= 2;
			//		colTmp += colTmp2;
			//	}
			//	else
			//	{
			//	}
			//	// ����ް��݂�����
			//	DrawLine(0, i, SCREEN_SIZE_X, i, GetColor(RGB[0], RGB[1], RGB[2]), true);

			//}

			if (lpGameTask.StageCnt == 0)
			{
				SetDrawBright(200 - (int)Fadeout[0], 180 - (int)Fadeout[1], 130 - (int)Fadeout[2]);
				DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, GetColor(100, 80, 30), true);
				DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 3, 0, ImageMng::GetInstance().SetID("image/landMap01.png"), true);
				DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 3, 0, ImageMng::GetInstance().SetID("image/landMap02.png"), true);
			}
			else if (lpGameTask.StageCnt == 1)
			{
				SetDrawBright(250 - (int)Fadeout[0], 180 - (int)Fadeout[1], 130 - (int)Fadeout[2]);
				DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, GetColor(150, 80, 30), true);
				DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 3, 0, ImageMng::GetInstance().SetID("image/landMap2-02.png"), true);
				DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 3, 0, ImageMng::GetInstance().SetID("image/landMap2-01.png"), true);
			}
			else if (lpGameTask.StageCnt == 2)
			{
				SetDrawBright(130 - (int)Fadeout[0], 180 - (int)Fadeout[1], 250 - (int)Fadeout[2]);
				DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, GetColor(30, 80, 150), true);
				DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 3, 0, ImageMng::GetInstance().SetID("image/landMap3-02.png"), true);
				DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 3, 0, ImageMng::GetInstance().SetID("image/landMap3-01.png"), true);
			}

			// �����̖ڈ�̓_��
			landPointAlpha[0] -= 3.0f;
			landPointAlpha[4] = landPointAlpha[0];
			if (landPointAlpha[0] < 128)
			{
				landPointAlpha[1] -= 3.0f;
				landPointAlpha[3] = landPointAlpha[1];
				if (landPointAlpha[1] < 128)
				{
					landPointAlpha[2] -= 3.0f;
				}
			}
			if (landPointAlpha[2] < 0)
			{
				for (int i = 0; i < 5; i++)
				{
					landPointAlpha[i] = 255;
				}
			}
			for (int i = 0; i < 5; i++)
			{
				SetDrawBlendMode(DX_BLENDMODE_ALPHA, landPointAlpha[i]);
				int color;
				if (stageCnt == 0)
				{
					color = GetColor(0, 0, 255);
				}
				else if (stageCnt == 1)
				{
					color = GetColor(0, 255, 0);
				}
				else if(stageCnt == 2)
				{
					color = GetColor(255, 0, 0);
				}
				if (stageCnt == 0)
				{
					DrawCircle(landingL.x + landingDiv * i, landingL.y, 4, color, true);
				}
				else if (stageCnt == 1)
				{
					DrawCircle(landingL.x + landingDiv * i - 50, landingL.y, 4, color, true);
				}
				else
				{
					DrawCircle(landingL.x + landingDiv * i + 30 , landingL.y, 4, color, true);
				}
				
				//DrawRotaGraph(landingL.x + landingDiv * i , landingL.y, 0.8f, 0, IMAGE_ID("image/light.png"), true);
			}
			/*DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 3, 0, ImageMng::GetInstance().SetID("image/landMap01.png"), true);
			DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 3, 0, ImageMng::GetInstance().SetID("image/landMap02.png"), true);*/

			if (pos.x < 280 && pos.y < 130)
			{
				if (landAlpha > 100)
				{
					landAlpha -= 15.0f;
				}
			}
			else
			{
				if (landAlpha < 255)
				{
					landAlpha += 15.0f;
				}
			}

			if (alpha >= 255)
			{
				SetDrawBlendMode(DX_BLENDMODE_ALPHA, landAlpha);
			}
			else
			{
				SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
			}
			DrawGraph(105, 44, ImageMng::GetInstance().SetID("image/sokudoUI.png"), true);
			DrawGraph(95, 56, ImageMng::GetInstance().SetID("image/speedUI_under.png"), true);
			DrawGraph(100, 77, ImageMng::GetInstance().SetID("image/kyoriUI.png"), true);
			DrawGraph(65, 89, ImageMng::GetInstance().SetID("image/speedUI_under.png"), true);
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);

			//SetFontSize(25);		// ̫�Ă̻���
			//SetFontThickness(5);	// ̫�Ă̑���
			//ChangeFont("Ailerons");

			if (alpha >= 255)
			{
				SetDrawBlendMode(DX_BLENDMODE_ALPHA, landAlpha);
			}
			else
			{
				SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
			}
			DrawFormatString(168, 50, GetColor(255, 255, 255),"%.0fkm/s", (speed * 4 >= 0 ? speed * 4 : 0));
			DrawFormatString(168, 82, GetColor(255, 255, 255), "%dkm", (int)distance);
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
			//SetFontSize(20);		// ̫�Ă̻���
			//SetFontThickness(8);	// ̫�Ă̑���
			//ChangeFont("MS�S�V�b�N");

			if (alpha >= 255)
			{
				SetDrawBlendMode(DX_BLENDMODE_ALPHA, landAlpha);
			}
			else
			{
				SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
			}
			DrawRotaGraph(60, 60, 2, spCAngleF, ImageMng::GetInstance().SetID("image/suihei01.png"), true);
			DrawRotaGraph(60, 60, 2, 0, ImageMng::GetInstance().SetID("image/suihei02.png"), true);
			DrawRotaGraph(60, 60, spCSize, spCAngleF, ImageMng::GetInstance().SetID("image/spCraft.png"), true);
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
			distance = (int)(landingL.y - (pos.y + offset));
			if (stageCnt == 0)
			{
				if (distance <= 455)
				{
					SetDrawBlendMode(DX_BLENDMODE_ALPHA, distance - 200);
				}
				DrawRotaGraphF(landingL.x + (landingR.x - landingL.x) / 2, landingL.y - sin(PI * 2 / 300 * count) * 5, 0.8, 0, IMAGE_ID("image/���.png"), true);
				SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
			}
			//SetDrawBlendMode(DX_BLENDMODE_ALPHA, 50);
			//DrawBox(landingL.x, landingL.y, landingR.x, landingR.y, 0x00ff00, true);
			//SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
			// �߰è�ٕ`��
			if (particleList.size() > 0)
			{
				for (auto itr : particleList)
				{
					itr->Draw();
					itr->Update();
				}
			}
			if (landAngle != -1)
			{
				DrawRotaGraphF(pos.x, pos.y + offset, 1.5, spCAngleF, ImageMng::GetInstance().SetID("image/spCraft.png"), true);
			}
			else
			{
				DrawRotaGraphF(pos.x, pos.y + offset, (AnimCnt * 0.2f) <= 1.5f ? (1.5 - (AnimCnt * 0.2f)) : 0, spCAngleF, ImageMng::GetInstance().SetID("image/spCraft.png"), true);
			}
			/*DrawCircle(pos.x, pos.y, 3, 0xffff00, true, true);
			DrawCircle(centerPosU.x, centerPosU.y, 3, 0xff0000, true, true);*/
			DrawRotaGraphF(paraPos.x, paraPos.y, 1.5, paraAngle, ImageMng::GetInstance().SetID("image/capsuleParaL02.png"), true);
			
			// �������̓����蔻��
			//DrawCircle(spCLine1U.x, spCLine1U.y, 3, 0x00ff00, true);
			//DrawCircle(spCLine2U.x, spCLine2U.y, 3, 0x00ff00, true);
			//DrawCircle(spCLine1D.x, spCLine1D.y, 3, 0x00ff00, true);
			//DrawCircle(spCLine2D.x, spCLine2D.y, 3, 0x00ff00, true);

			// �����蔻�����Ō��񂾕�
			/*DrawLine(spCLine2U.x, spCLine2U.y, spCLine1U.x, spCLine1U.y, 0x0000ff, true);
			DrawLine(spCLine2D.x, spCLine2D.y, spCLine1D.x, spCLine1D.y, 0x0000ff, true);
			DrawLine(spCLine2U.x, spCLine2U.y, spCLine2D.x, spCLine2D.y, 0x0000ff, true);
			DrawLine(spCLine1U.x, spCLine1U.y, spCLine1D.x, spCLine1D.y, 0x0000ff, true);*/

		}
		else if (pos.y > 0)
		{
			if (anim >= 8)
			{
				anim = 8;
			}
			else
			{
				anim = (animCnt++ / 125) % 10;
			}
		}
		else
		{
			anim = 0;
		}
		if (shieldFlag)
		{
			DrawRotaGraphF(pos.x, pos.y, 2.5, angle, capsulePara[anim], true);
			DrawRotaGraphF(shieldPos.x, shieldPos.y, 2.5, shieldAngle, ImageMng::GetInstance().SetID("image/shield.png"), true);
			//SetFontSize(15);
			DrawRotaGraph(SCREEN_SIZE_X - 100, SCREEN_SIZE_Y - 15, 1.0, 0, IMAGE_ID("image/spaceSkip.png"), true);
			//SetFontSize(20);
		}
	}

	//SetDrawBlendMode(DX_BLENDMODE_ADD,100);
	//SetDrawBright(150, 128, 0);
	//SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

	//DrawFormatString(SCREEN_SIZE_X /2, SCREEN_SIZE_Y/2, 0xffffff, "scene:%d",scene);
	//DrawFormatString(0, 15, 0xffffff, "motherPos.x:%f,motherPos.y:%f", motherPos.x, motherPos.y);
	//DrawFormatString(0, 30, 0xffffff, "cupPos.x:%f,cupPos.y:%f", cupPos.x, cupPos.y);
	//DrawFormatString(0, 45, 0xffffff, "speed:%f", speed);
	//DrawFormatString(0, 80, 0xffffff, "pos.x:%f,pos.y:%f", motherPos.x, motherPos.y);
}

void LandPlayer::Update(void)
{
	//DrawBox(0, 0, 280, 130, 0xffffff, false);

	lpGameTask.SetScene((float)scene);
	lpGameTask.SetLdistance((float)distance);

	Cinema();

	// ��ݽ����
	if (KeyMng::GetInstance().trgKey[P1_SPACE] && skipCnt == 0 && motherPos.y > 100)
	{
		shieldFlag = false;
		lpGameTask.SetCupLandCheck(true);
		lpGameTask.SetDarkFlag2(true);
		skipFlag = true;
		sinFlag = false;
		skipCnt++;
	}

	count++;
	if (motherPos.y < SCREEN_SIZE_Y / 2)
	{
		countF += 0.001f;
	}
	else
	{
		countF -= 0.001f;
		if (sinFlag == true)
		{
			countF = 0.0f;
		}
	}
	if (motherPos.y < SCREEN_SIZE_Y / 4)
	{
		motherPos.y += 0.03f + countF;
	}
	else
	{
		if (cupPos.y == 0)
		{
			cupPos = motherPos;
			motherPos.y += 20;
		}
		if (scene == 0)
		{
			sinFlag = true;
		}
	}

	if (sinFlag == true)
	{
		motherPos.y = -sin(PI * 2 / 600 * count) * 5;
		motherPos.y += SCREEN_SIZE_Y / 4;

		colorPos = GetPixel(cupPos.x, cupPos.y + 10);
		if (colorPos == color);
		{
			if (size >= 0)
			{
				size -= 0.005f;
				if (scene != 2)
				{
					pos.x = 40;
					pos.y = -(int)PLAYER_SIZE;
				}
			}
			else
			{
				sinFlag = false;
				scene = 1;
				lpGameTask.SetCupLandCheck(true);
			}
		}
	}
	if (count > 1000)
	{
		injectionFlag = true;
	}
	if (injectionFlag == true)
	{
		cupPos.y += 1.0f;
	}

	if (shieldFlag)
	{
		if (anim < 5 && lpGameTask.darkFlag == true && !lpGameTask.GetDarkFlag2())
		{
			angle = -0.3f;
			shieldAngle = angle;
			shieldPos.x = pos.x + 8;
			shieldPos.y = pos.y + 31;
			pos.x += 0.3f;
			pos.y += 0.6f;
		}
		else
		{
			if (angle < 0.0f)
			{
				angle += 0.001f;
			}
			else
			{
				angle = 0.0f;
			}
			shieldPos.x -= 0.2f;
			shieldPos.y += 0.8f;
			shieldAngle += 0.01f;
			pos.y += 0.40f;
		}
	}
	else
	{
		lpGameTask.SetSpr(separateFlag);
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, alphaChaku);
		DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 1, 0, ImageMng::GetInstance().SetID("image/chakuriku_kana.png"), true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alphaChaku);
		if (SCREEN_SIZE_Y / 4 < pos.y + vy && scene == 2)
		{
			separateFlag = true;
			if (alphaChaku > 0)
			{
				alphaChaku -= 20;
			}
		}
		else
		{
			if (alphaChaku < 255)
			{
				alphaChaku += 10;
			}
		}
		scene = 2;
		if (skipFlag == true && skipCnt == 1)
		{
			pos.x = SCREEN_SIZE_X / 2;
			pos.y = -100;
			pos = paraPos;
			skipCnt++;
		}

		if (separateFlag)
		{
			if(vy < 1.0f && landAngle != 1)
			vy += 0.0025f;
			paraPos.x -= 0.20f;
			paraPos.y += 0.30f;
			paraAngle -= 0.0003f;
			/*pos.x += vx;
			pos.y += vy;*/
			//pos = paraPos;
			if(landAngle == 0)
			SetMove();
		}
		else
		{
			vy = 0.40f;
			paraPos.x = pos.x;
			paraPos.y = pos.y + vy;
			pos = paraPos;
		}
	}

	if (pos.y - 100 > SCREEN_SIZE_Y)
	{
		lpGameTask.SetDarkFlag2(true);
		pos.x = SCREEN_SIZE_X / 2;
		pos.y = -100;
		anim = 0;
		animCnt = 0;						// DrawRotaGraph(pos.x, pos.y, 2, 0, capsuleParaLAnim[anim], true);��anim��1����n�܂��Ă��܂�����
		shieldFlag = false;
	}

	offset = 45;
	VECTOR3 spCHarf = {(SPC_SIZE_X * spCSize)/3,(SPC_SIZE_Y * spCSize)/3 };
	VECTOR3 spCraftPosR(pos.x + spCHarf.x, pos.y + spCHarf.y + offset);
	VECTOR3 spCraftPosL(pos.x - spCHarf.x, pos.y - spCHarf.y + offset);

	// �����蔻��

	// �����蔻�����邽�߂̑O����W(�㉺)
	centerPosU.x = pos.x + (20 * sin(spCAngleF));
	centerPosU.y = (offset) + pos.y + (-20 * cos(spCAngleF));
	centerPosD.x = pos.x + (20 * sin(-spCAngleF));
	centerPosD.y = (offset) + pos.y + (20 * cos(spCAngleF));

	// �E����W
	spCLine1U.x = centerPosU.x + (25 * cos(spCAngleF));
	spCLine1U.y = centerPosU.y + (25 * sin(spCAngleF));

	// ������W
	spCLine2U.x = centerPosU.x + (25 * cos(spCAngleF + PI));
	spCLine2U.y = centerPosU.y + (25 * sin(spCAngleF + PI));

	// �E�����W
	spCLine1D.x = centerPosD.x + (25 * cos(spCAngleF));
	spCLine1D.y = centerPosD.y + (25 * sin(spCAngleF));

	// �������W
	spCLine2D.x = centerPosD.x + (25 * cos(spCAngleF + PI));
	spCLine2D.y = centerPosD.y + (25 * sin(spCAngleF + PI));

	/*sidePos.x = turnPos.x + ((13 * sin(-count / 2)) * (sideCheck == 2 ? 1 : -1));
	sidePos.y = turnPos.y + ((13 * cos(count / 2)) * (sideCheck == 2 ? 1 : -1));*/

	int r = 0, g = 0, b = 0, a = 0;
	int x = 0, y = 0;

	for (int i = 0; i < mapImageSize.x; i++)
	{
		for (int j = 0; j < mapImageSize.y; j++)
		{
			GetPixelSoftImage(mapSoft, i, j, &r, &g, &b, &a);

			if (a > 0)
			{
				if (scene == 2)
				{
					VECTOR3 mapPosL(i * mapSize, j * mapSize);
					VECTOR3 mapPosR(((i - 2)) * mapSize, (j - 2) * mapSize);

					if (lpGameTask.StageCnt == 0)
					{
						landingL = { 65 * 3,240 * 3 };
						landingR = { 100 * 3,240 * 3 };
					}
					else if (lpGameTask.StageCnt == 1)
					{
						landingL = { 35 * 3,240 * 3 };
						landingR = { 70 * 3,240 * 3 };
					}
					else if (lpGameTask.StageCnt == 2)
					{
						landingL = { 95 * 3,240 * 3 };
						landingR = { 130 * 3,240 * 3 };
					}
					//landingR = { 100 * 3,250 * 3 };

					DrawBox(landingL.x, landingL.y, landingR.x, landingR.y, 0xff00ff, true);
					//DrawBox(spCraftPosL.x, spCraftPosL.y, spCraftPosR.x, spCraftPosR.y, 0x00ff00, false);
					//DrawFormatString(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 0xffffff, "Angle:%d", deg);

					VECTOR3 landingPointVec = landingL - landingR;
					float landingPointDistance = sqrt((landingPointVec.x * landingPointVec.x) + (landingPointVec.y * landingPointVec.y));
					//DrawFormatString(100, 100, 0xffffff, "%f", landingPointDistance);
					landingDiv = landingPointDistance / 5;

					// ����
					//DrawCircle(landingL.x, landingL.y, 3, 0xff0000, true);

					// �E��
					//DrawCircle(landingR.x, landingR.y, 3, 0x0000ff, true);
					
					if ((landingR.x > spCLine2D.x && landingL.x < spCLine1D.x))
					{
						if ((landingR.y < spCLine2D.y || landingL.y < spCLine1D.y))
						{
							hitPos.x = pos.x;
							hitPos.y = pos.y;
							pos = hitPos;
							if (((deg < 25 && deg > -25) || (deg < 340 && deg > -340)) && (vy <= 0.5f))
							{
								landAngle = 1;
							}
							else
							{
								hitPos.y = pos.y;
								pos = hitPos;
								landAngle = -1;
							}
						}
					}
					else if ((mapPosR.x > spCraftPosL.x && mapPosL.x < spCraftPosR.x))
					{
						if ((mapPosR.y > spCraftPosL.y && mapPosL.y < spCraftPosR.y))
						{
							hitPos.x = pos.x;
							hitPos.y = pos.y;
							pos = hitPos;
							landAngle = -1;
						}
					}
				}
			}
			//x = i;
			//y = j;
		}
	}

	// ��ʊO�ł�����
	if (pos.x < 0 || pos.x > SCREEN_SIZE_X)
	{
		hitPos.x = pos.x;
		hitPos.y = pos.y;
		pos = hitPos;
		landAngle = -1;
	}

	// ����������
	if (landAngle == 1)
	{
		if (lpGameTask.StageCnt == 0)
		{
			for (int i = 0; i < 3; i++)
			{
				auto fadeMax = (i == 0 ? 200 : (i == 1 ? 180 : 130));

				if (fadeMax - Fadeout[i] > 0)
				{
					if (lpGameTask.StageCnt == 0)
					{
						Fadeout[i] += (i == 0 ? 2.0f : (i == 1 ? 1.8f : 1.3f));
					}
					else if (lpGameTask.StageCnt == 1)
					{
						Fadeout[i] += (i == 0 ? 2.5f : (i == 1 ? 1.8f : 1.3f));
					}
					else if (lpGameTask.StageCnt == 2)
					{
						Fadeout[i] += (i == 0 ? 1.3f : (i == 1 ? 1.8f : 2.5f));
					}
				}
			}
		}
		if (deg != 0)
		{
			deg = 180 * spCAngleF / PI;

			if (deg > 0)
			{
				spCAngleF -= 0.004f;
			}
			else if (deg < 0)
			{
				spCAngleF += 0.004f;
			}
			// Y���̕␳
			pos.y += 0.06f;
		}
		else
		{
			GameLight--;
			SetDrawBright(GameLight, GameLight, GameLight);
			if (GameLight <= 0)
			{
				lpGameTask.landAnimFlag = true;
				/*SetDrawBright(0, 0, 0);
				Fadeout[0] = { 0 };
				Fadeout[1] = { 0 };
				Fadeout[2] = { 0 };*/
			}
		}
	}

	// �������s��
	if (landAngle == -1)
	{
		if (AnimTime++ % 15 == 0)
		{
			AnimCnt++;
		}
		// ����
		DrawRotaGraph((int)pos.x, (int)pos.y + offset, 1.0, 0, DieAnim[AnimCnt], true);

		if (AnimCnt >= 11)
		{
			if (lpGameTask.StageCnt == 0)
			{
				for (int i = 0; i < 3; i++)
				{
					auto fadeMax = (i == 0 ? 200 : (i == 1 ? 180 : 130));

					if (fadeMax - Fadeout[i] > 0)
					{
						Fadeout[i] += (i == 0 ? 2.0f : (i == 1 ? 1.8f : 1.3f));
					}
				}
			}
			GameLight--;
			SetDrawBright(GameLight, GameLight, GameLight);
		}
		// ؾ��
		if (GameLight < 0)
		{
			lpGameTask.landGameCheck = true;
			lpGameTask.SetHitCheck(true);
			vx = 0;
			vy = 0.40f;
			pos.x = SCREEN_SIZE_X / 2;
			pos.y = -100;
			paraPos.x = pos.x;
			paraPos.y = pos.y + vy;
			pos = paraPos;
			landAngle = 0;
			deg = 0;
			spCAngleF = 0;
			spCAngle = 0;
			paraAngle = 0;
			rolInc = 0;
			lrFlag = 0;
			AnimTime = 0;
			AnimCnt = 0;
			GameLight = 255;
			separateFlag = false;
			Fadeout[0] = { 0 };
			Fadeout[1] = { 0 };
			Fadeout[2] = { 0 };
			alpha = 0;
			lpGameTask.SetAlpha(0);
		}
	}
	lpGameTask.SetLandAngle(landAngle);
	lpGameTask.SetPlayerPos(pos);
	//GetPixelSoftImage(mapSoft, 449, 799, &r, &g, &b, &a);
	/*DrawFormatString(10, 500, 0xffffff, "skipFlag:%d skipCnt:%d", skipFlag,skipCnt);
	DrawFormatString(10, 550, 0xffffff, "vecX %f vecY %f", vx, vy);
	DrawFormatString(10, 650, 0xffffff, "GetLandingCnt1 %d GetLandingCnt2 %d", lpGameTask.GetLandingCnt(0), lpGameTask.GetLandingCnt(1));*/
}

void LandPlayer::SetMove(void)
{
	auto AddPtclist = [&](land_ptr && objPtr)
	{
		particleList.push_back(objPtr);
		auto itr = particleList.end();
		itr--;
		return itr;
	};

	auto OneVec = [&](VECTOR3 vec)
	{
		return VECTOR3(vec.x == 0 ? 0 : (vec.x < 0 ? -1 : 1), vec.y == 0 ? 0 : (vec.y < 0 ? -1 : 1));
	};

	VECTOR3 vec = { 0,0 };
	auto randomX = GetRand(10);
	pos.x = pos.x + vx;
	pos.y = pos.y + vy;
	spCAngleF += spCAngle + rolInc;
	deg = 180 * spCAngleF / PI;
	if (deg > 360)
	{
		spCAngleF = 0;
	}
	if (deg < -360)
	{
		spCAngleF = 0;
	}
	if (KeyMng::GetInstance().newKey[P1_UP])
	{
		if (speed < 1.0f)
		{
			speed += 0.003f;
		}
		particleFlag = true;
		parListFlag[1] = true;

		particleSpeed = 3.0f;

		vx += sin(spCAngleF) * 0.0025f;
		vy += -cos(spCAngleF) * 0.005f;

		vec.x = sin(spCAngleF);
		vec.y = -(cos(spCAngleF));
	}
	else
	{
		if (speed > -1.0f)
		{
			speed -= 0.003f;
		}
		particleFlag = false;
		for (int p = 0; p < parDirMax; p++)
		{
			parListFlag[p] = false;
		}

		particleSpeed -= 0.1f;
	}
	if (KeyMng::GetInstance().newKey[P1_RIGHT])
	{
		spCAngle += 0.0001f;
		lrFlag = 1;
		particleFlag = true;
		parListFlag[0] = true;
	}
	else
	{
		parListFlag[0] = false;
	}
	if (KeyMng::GetInstance().newKey[P1_LEFT])
	{
		spCAngle -= 0.0001f;
		lrFlag = -1;
		particleFlag = true;
		parListFlag[2] = true;
	}
	else
	{
		parListFlag[2] = false;
	}
	
	if (lrFlag == 1)
	{
		rolInc = 0.000005f;
	}
	else if (lrFlag == -1)
	{
		rolInc = -0.000005f;
	}

	// �߰è�ٍ쐬
	if (particleFlag)
	{
		float parMax = 1.0f;
		for (float f = 0.0; f < parMax; f += 0.1)
		{
			// �^��
			if(parListFlag[1])
			particle = AddPtclist(std::make_shared<Particle>(VECTOR3(centerPosD.x + (randomX * 0.1f),centerPosD.y), (vec*f)*particleSpeed, 3));
			// �E��
			if(parListFlag[2])
			particle = AddPtclist(std::make_shared<Particle>(VECTOR3(spCLine1D.x + (randomX * 0.1f), spCLine1D.y), ((vec*f)*(particleSpeed - 1.0f)), 0));
			// ����
			if (parListFlag[0])
			particle = AddPtclist(std::make_shared<Particle>(VECTOR3(spCLine2D.x + (randomX * 0.1f), spCLine2D.y), ((vec*f)*(particleSpeed - 1.0f)), 0));
		}
	}
	// �߰è�ق̍폜
	for (int i = 0; i < particleList.size(); i++)
	{
		if (particleList.size() > 0)
		{
			if (particleList.front()->GetTimer() > 12)
			{
				if (!(particleList.empty()))
				{
					particleList.pop_front();
				}
			}
		}
	}
	//DrawFormatString(10, 600, 0xffffff, "posX %f posY %f", sin(spCAngleF), -cos(spCAngleF));
}

void LandPlayer::Cinema(void)
{
	if (!separateFlag)
	{
		if (cineBox1.d < 50.0f)
		{
			cineBox1.d += 0.2f;
		}
		if (cineBox2.u > 750.0f)
		{
			cineBox2.u -= 0.2f;
		}
		DrawBox(cineBox1.l, cineBox1.u, cineBox1.r, cineBox1.d, 0x000000, true);
		DrawBox(cineBox2.l, cineBox2.u, cineBox2.r, cineBox2.d, 0x000000, true);
	}
	else
	{
		if (lpGameTask.GetAlpha() < 255)
		{
			alpha += 1.0f;
			lpGameTask.SetAlpha(alpha);
		}
		if (cineBox1.d > 0.0f)
		{
			cineBox1.d -= 0.5f;
		}
		if (cineBox2.u < 800.0f)
		{
			cineBox2.u += 0.5f;
		}
		DrawBox(cineBox1.l, cineBox1.u, cineBox1.r, cineBox1.d, 0x000000, true);
		DrawBox(cineBox2.l, cineBox2.u, cineBox2.r, cineBox2.d, 0x000000, true);
	}

	blinkCnt++;

	//SetFontSize(15);
	if (blinkCnt / 90 % 2 == 0)
	{
		if (scene != 2)
		{
			if (motherPos.y > 100)
			{
				DrawRotaGraph(SCREEN_SIZE_X - 100, SCREEN_SIZE_Y - 15, 1.0, 0, IMAGE_ID("image/spaceSkip.png"), true);
			}
		}
	}
	//SetFontSize(20);
}
