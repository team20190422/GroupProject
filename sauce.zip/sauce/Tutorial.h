#pragma once

class Tutorial {
public:
	Tutorial();
	~Tutorial();
	void Draw();
	void Update();
private:
};