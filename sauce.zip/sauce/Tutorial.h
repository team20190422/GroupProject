#pragma once

class Tutorial {
public:
	Tutorial();
	~Tutorial();
	void Init();
	void Draw();
	void Update();
private:
	int alpha = 255;
	int count = 0;
};