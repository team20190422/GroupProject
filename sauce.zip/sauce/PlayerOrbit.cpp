#include "PlayerOrbit.h"
#include "BasePlanet.h"
#include "ImageMng.h"
#include "KeyMng.h"
#include "OrbitPoint.h"		// �m�F

PlayerOrbit::PlayerOrbit(const VECTOR3& DofT,const VECTOR3& pPos, const float& vy):Player(trgKey, oldKey)
{
	vec = DofT;
	pos = pPos;
	v = vy / 2;
}

PlayerOrbit::~PlayerOrbit()
{
}

const VECTOR3 & PlayerOrbit::GetVec1(void)
{
	return vector;
}

void PlayerOrbit::SetVec1(VECTOR3 vec)
{
	vector = vec;
}

const float & PlayerOrbit::GetOrbDistance(void)
{
	return orbDistance;
}

void PlayerOrbit::SetOrbDistance(float dis)
{
	orbDistance = dis;
}

const VECTOR3 & PlayerOrbit::GetOrbPos(void)
{
	return this->pos;
}

void PlayerOrbit::SetVector(VECTOR3 vec)
{
	this->vec = vec;
}

void PlayerOrbit::SetPosition(VECTOR3 pos)
{
	this->pos = pos;
}

void PlayerOrbit::SetSpeed(float speed)
{
	this->speed = speed;
}

void PlayerOrbit::SetOutOfScreen(bool inScreen)
{
	this->inScreen = inScreen;
}

const bool & PlayerOrbit::GetOutOfScreen()
{
	return inScreen;
}


void PlayerOrbit::Update()
{
	count++;
	mgn = sqrt((vec.x * vec.x) + (vec.y * vec.y));
	uniVec = vec / mgn;
	SetVec1(vec);

	planetPos.resize(lpGameTask.planetMax);
	planetGravity.resize(lpGameTask.planetMax);
	distanceMin = 10000.0f;
	for (int i = 0; i < lpGameTask.planetMax; i++)
	{
		planetPos[i] = lpGameTask.GetPlanetPositon(i);
		planetGravity[i] = lpGameTask.GetPlanetGravity(i);

		float a = abs(planetPos[i].x - pos.x);
		float b = abs(planetPos[i].y - pos.y);
		distance = sqrt((a * a) + (b * b));
		if (distance < distanceMin)
		{
			distanceMin = distance;
			planetPosSave = planetPos[i];
			saveGravity = planetGravity[i];
		}
		//DrawFormatString(20, SCREEN_SIZE_Y / 2 + 50 + 15 * i, 0xffffff, "planetX:%.3f,planetY:%.3f,D:%.3f", planetPos[i].x, planetPos[i].y,distanceMin);
		//DrawFormatString(20, SCREEN_SIZE_Y / 2 + 50 + 15 * i, 0xffffff, "Gravity:%f",planetGravity[i]);
	}

	if (count % 20 == 0)
	{
  		point.push_back(std::make_shared<OrbitPoint>(vec, pos, v));
		pointPosition.resize(point.size());
		pointPosition[count / 20] = pos;
		countFlag = true;
	}
	else
	{
		countFlag = false;
	}

	for (auto i : point)
	{
		if (countFlag)
		{
			for (int j = 0; j < point.size(); j++)
			{
				i->SetPointPos(pointPosition[j]);
			}
		}
		i->Update();
		i->Draw();
	}
	DrawFormatString(20, SCREEN_SIZE_Y / 2, 0xffffff, "pointSize:%d",point.size());
	SetMove();

	auto angle = atan2(planetPosSave.x - pos.x,planetPosSave.y - pos.y);
	gVec.x = sin(angle);
	gVec.y = -cos(angle);
	EofG = saveGravity;
	//DrawFormatString(20, SCREEN_SIZE_Y / 2 + 20, 0xffffff, "Gravity:%f", EofG);
	addVec = AddVec((Obj::Normalize(gVec, distanceMin) * EofG), vec);
	test = (Obj::Normalize(gVec, distanceMin) * EofG);
	//DrawFormatString(50, SCREEN_SIZE_Y / 2, 0xffffff, "X:%f,Y:%f", test.x,test.y);
	SetVector(addVec);

	if (pos.x < 0 || pos.x > SCREEN_SIZE_X || pos.y < 0 || pos.y > SCREEN_SIZE_Y)
	{
		inScreen = false;
	}
	else
	{
		inScreen = true;
	}

	SetOutOfScreen(inScreen);
}

void PlayerOrbit::Draw()
{
	DrawLine(pos.x, pos.y, planetPosSave.x, planetPosSave.y, 0xff00ff, true);
	//DrawLine(pos.x, pos.y, test.x, test.y, 0xffff00, true);
	DrawCircle(pos.x, pos.y, 2, 0x66B3FF, true);
}

void PlayerOrbit::SetMove()
{
	pos += addVec * speed;
	//DrawFormatString(50, SCREEN_SIZE_Y / 2, 0xffffff, "addVec.x:%.3f,addVec.y:%.3f",addVec.x, addVec.y);
}
