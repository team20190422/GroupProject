#include "PlayerOrbit.h"
#include "ImageMng.h"

PlayerOrbit::PlayerOrbit(const VECTOR3& DofT,const VECTOR3& pPos, const float& vy):Player(trgKey, oldKey)
{
	vec = DofT;
	pos = pPos;
	v = vy / 2;
}

PlayerOrbit::~PlayerOrbit()
{
}

const VECTOR3 & PlayerOrbit::GetVec1(void)
{
	return vector;
}

void PlayerOrbit::SetVec1(VECTOR3 vec)
{
	vector = vec;
}

const float & PlayerOrbit::GetOrbDistance(void)
{
	return orbDistance;
}

void PlayerOrbit::SetOrbDistance(float dis)
{
	orbDistance = dis;
}


void PlayerOrbit::Update()
{
	mgn = sqrt((vec.x * vec.x) + (vec.y * vec.y));
	uniVec = vec / mgn;
	SetVec1(vec);

	//distance = 
	gVec = {lpGameTask.GetPlanetPos().x - pos.x,lpGameTask.GetPlanetPos().y - pos.y };
	//auto addVec = AddVec((Obj::Normalize((gVec), distance) * EofG), vec);// Obj::Normalize(vec, vecMgn));
	SetMove();
}

void PlayerOrbit::Draw()
{
	DrawLine(pos.x, pos.y, lpGameTask.GetPlanetPos().x, lpGameTask.GetPlanetPos().y, 0xff00ff, true);
	DrawCircle(pos.x, pos.y, 2, 0x66B3FF, true);
}

void PlayerOrbit::SetMove()
{
	pos += vec * v;
}
