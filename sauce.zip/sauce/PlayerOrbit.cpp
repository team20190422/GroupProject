#include "PlayerOrbit.h"
#include "ImageMng.h"

PlayerOrbit::PlayerOrbit(const VECTOR3& DofT,const VECTOR3& pPos):Player(trgKey, oldKey)
{
	insCount++;
	vec = DofT;
	pos = pPos;
}

PlayerOrbit::~PlayerOrbit()
{
}

void PlayerOrbit::Update()
{

}

void PlayerOrbit::Draw()
{
}

int PlayerOrbit::GetInstanceCnt()
{
	return insCount;
}
