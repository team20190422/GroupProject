#include "PlayerOrbit.h"
#include "ImageMng.h"

PlayerOrbit::PlayerOrbit(const VECTOR3& DofT,const VECTOR3& pPos, const float& vy):Player(trgKey, oldKey)
{
	vec = DofT;
	pos = pPos;
	v = vy;
}

PlayerOrbit::~PlayerOrbit()
{
}

const VECTOR3 & PlayerOrbit::GetVec1(void)
{
	return vector;
}

void PlayerOrbit::SetVec1(VECTOR3 vec)
{
	vector = vec;
}


void PlayerOrbit::Update()
{
	mgn = sqrt((vec.x * vec.x) + (vec.y * vec.y));
	uniVec = vec / mgn;
	SetVec1(vec);
	SetMove();
}

void PlayerOrbit::Draw()
{
	DrawCircle(pos.x, pos.y, 10, 0xffffff, true);
}

void PlayerOrbit::SetMove()
{
	pos += uniVec * v;
}
