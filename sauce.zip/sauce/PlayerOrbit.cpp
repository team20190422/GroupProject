#include "PlayerOrbit.h"

PlayerOrbit::PlayerOrbit(const VECTOR3& DofT,const VECTOR3& pPos, const float& v):Player(trgKey, oldKey)
{
	vec = DofT;
	pos = pPos;
	vx = v;
}

PlayerOrbit::~PlayerOrbit()
{
}

void PlayerOrbit::Update()
{
	SetMove();
}

void PlayerOrbit::Draw()
{
	DrawCircle(pos.x , pos.y, 10, 0xffffff, true);
}

void PlayerOrbit::SetMove()
{
	pos += vec;
}
