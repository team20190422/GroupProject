#include "PlayerOrbit.h"
#include "BasePlanet.h"
#include "ImageMng.h"
#include "KeyMng.h"
#include "OrbitPoint.h"
#include "Asteroid.h"

constexpr int PUSH_TIMER = 10;

PlayerOrbit::PlayerOrbit(const VECTOR3& DofT,const VECTOR3& pPos, const float& vy):Player(trgKey, oldKey)
{
	vec = DofT;
	pos = pPos;
	v = vy /*/ 2*/;
	hitFlag = false;
}

PlayerOrbit::~PlayerOrbit()
{
}

const VECTOR3 & PlayerOrbit::GetVec1(void)
{
	return vector;
}

void PlayerOrbit::SetVec1(VECTOR3 vec)
{
	vector = vec;
}

const float & PlayerOrbit::GetOrbDistance(void)
{
	return orbDistance;
}

void PlayerOrbit::SetOrbDistance(float dis)
{
	orbDistance = dis;
}

void PlayerOrbit::SetVector(VECTOR3 vec)
{
	this->vec = vec;
}

void PlayerOrbit::SetPosition(VECTOR3 pos)
{
	this->pos = pos;
}

void PlayerOrbit::SetSpeed(float speed)
{
	this->speed = speed;
}

void PlayerOrbit::SetSpeedV(float speed)
{
	speedV = {speed ,speed};
}

const bool & PlayerOrbit::GetOrbitRemove()
{
	return orbitRemove;
}

void PlayerOrbit::SetOrbitRemove(bool rm)
{
	orbitRemove = rm;
}


void PlayerOrbit::Update()
{
	count++;
	mgn = sqrt((vec.x * vec.x) + (vec.y * vec.y));
	uniVec = vec / mgn;
	//SetVec1(vec);

	planetPos.resize(lpGameTask.planetMax);
	planetGravity.resize(lpGameTask.planetMax);
	distanceMin = 10000.0f;
	for (int i = 0; i < lpGameTask.planetMax; i++)
	{
		planetPos[i] = lpGameTask.GetPlanetPosition(i);
		//planetGravity[i] = lpGameTask.GetPlanetGravity(i);

		float a = abs(planetPos[i].x - pos.x);
		float b = abs(planetPos[i].y - pos.y);
		distance = sqrt((a * a) + (b * b));
		if (distance < distanceMin)
		{
			distanceMin = distance;
			planetPosSave = planetPos[i];
			saveGravity = planetGravity[i];
		}
		//DrawFormatString(20, SCREEN_SIZE_Y / 2 + 50 + 15 * i, 0xffffff, "planetX:%.3f,planetY:%.3f,D:%.3f", planetPos[i].x, planetPos[i].y,distanceMin);
		//DrawFormatString(20, SCREEN_SIZE_Y / 2 + 50 + 15 * i, 0xffffff, "Gravity:%f",planetGravity[i]);
	}

	if (count % PUSH_TIMER == 0)
	{
		point.push_back(std::make_shared<OrbitPoint>(vec, pos, v, point.size() + 1));
		pointPosition.resize(point.size());
		pointPosition[count / PUSH_TIMER - 1] = pos;
		point[point.size() - 1]->SetPointPos(pointPosition[point.size() - 1], point.size() - 1);
	}

	for (auto i : point)
	{
		for(int j = 0; j < point.size();j++)
		if (KeyMng::GetInstance().trgKey[P1_UP] && KeyMng::GetInstance().trgKey[P1_SPACE])
		{
			i->SetPointPos(pos,j);
		}
		i->Update();
		i->Draw();
	}

	pItr = point.begin();
	while(pItr != point.end())
	{
		if ((*pItr)->GetRemove())
		{
			count -= PUSH_TIMER;
			point.erase(pItr);
			break;
		}
		else
		{
			pItr++;
		}
	}

	//DrawFormatString(20, SCREEN_SIZE_Y / 2, 0xffffff, "pointSize:%d",point.size());
	//DrawFormatString(20, SCREEN_SIZE_Y / 2 + 50 + 15, 0xffffff, "point:%d", pointPosition.size());

	//auto angle = atan2(planetPosSave.x - pos.x,planetPosSave.y - pos.y);
	//gVec.x = sin(angle);
	//gVec.y = cos(angle);
	//EofG = saveGravity;
	//DrawFormatString(20, SCREEN_SIZE_Y / 2 + 20, 0xffffff, "Gravity:%f", EofG);
	//addVec = AddVec((Obj::Normalize(gVec, distanceMin) * EofG), vec);
	//test = (Obj::Normalize(gVec, distanceMin) * EofG);
	//DrawFormatString(50, SCREEN_SIZE_Y / 2, 0xffffff, "X:%f,Y:%f", test.x,test.y);
	//SetVector(addVec);

	SetMove();


	//int r = 0, g = 0, b = 0, a = 0;

	//GetPixelSoftImage(lpGameTask.GetSoftImg(lpGameTask.GetAnimNum()), x, y, &r, &g, &b, &a);

	// �f���ɓ����������������
	int a = lpGameTask.GetAnimNum();

	VECTOR3 posL = { pos.x - (ORBIT_SIZE), pos.y - (ORBIT_SIZE) };
	VECTOR3 posR = { pos.x + (ORBIT_SIZE), pos.y + (ORBIT_SIZE) };

	VECTOR3 asteroidPosL;
	VECTOR3 asteroidPosR;

	for (int i = 0; i < lpGameTask.planetMax; i++)
	{
		if (i % 3 == 0)
		{
			asteroidPosL = { lpGameTask.GetAstPos(i).x - (IMG_SIZE / 2) - 15, lpGameTask.GetAstPos(i).y - (IMG_SIZE / 2) - 15 };
			asteroidPosR = { lpGameTask.GetAstPos(i).x + (IMG_SIZE / 2) + 15, lpGameTask.GetAstPos(i).y + (IMG_SIZE / 2) + 15 };
		}
		else if (i % 3 == 1)
		{
			asteroidPosL = { lpGameTask.GetAstPos(i).x - (IMG_SIZE / 2) - 15, lpGameTask.GetAstPos(i).y - (IMG_SIZE / 2) - 5 };
			asteroidPosR = { lpGameTask.GetAstPos(i).x + (IMG_SIZE / 2) + 15, lpGameTask.GetAstPos(i).y + (IMG_SIZE / 2) + 5 };
		}
		else
		{
			asteroidPosL = { lpGameTask.GetAstPos(i).x - (IMG_SIZE / 2) - 15, lpGameTask.GetAstPos(i).y - (IMG_SIZE / 2) + 3 };
			asteroidPosR = { lpGameTask.GetAstPos(i).x + (IMG_SIZE / 2) + 15, lpGameTask.GetAstPos(i).y + (IMG_SIZE / 2) - 3};
		}
		

		if (asteroidPosR.x > posL.x && asteroidPosL.x < posR.x)
		{
			if (asteroidPosR.y > posL.y && asteroidPosL.y < posR.y)
			{
				hitFlag = true;
			}
		}
		//DrawBox(asteroidPosL.x, asteroidPosL.y, asteroidPosR.x, asteroidPosR.y, GetColor(255, 0, 0), false);
	}
	//DrawBox(posL.x, posL.y, posR.x, posR.y, 0xffffff, false);

	if (pos.x < 0 || pos.x > SCREEN_SIZE_X || pos.y < 0 || pos.y > SCREEN_SIZE_Y || hitFlag)
	{
		SetOrbitRemove(true);
	}

	//DrawFormatString(50, SCREEN_SIZE_Y / 2, 0xffffff, "addVec.x:%.3f,addVec.y:%.3f", addVec.x, addVec.y);
	//DrawFormatString(50, SCREEN_SIZE_Y / 2 + 15, 0xffffff, "EofG.x:%.3f", EofG);
	//DrawFormatString(50, SCREEN_SIZE_Y / 2 + 30, 0xffffff, "vec.x:%.3f,vec.y:%.3f", vec.x, vec.y);
}

void PlayerOrbit::Draw()
{
	//DrawLine(pos.x, pos.y, planetPosSave.x, planetPosSave.y, 0xff00ff, true);
	//DrawLine(pos.x, pos.y, test.x, test.y, 0xffff00, true);
	DrawCircle(pos.x, pos.y, ORBIT_SIZE, 0x66B3FF, true);
}

void PlayerOrbit::SetMove()
{
	//pos += uniVec;
	finalVec = { 0.0f ,0.0f };
	for (int i = 0; i < lpGameTask.planetMax; i++)
	{
		auto addVec = Obj::Normalize(lpGameTask.GetPlanetToPlayerVector(i), lpGameTask.GetPlanetToPlayerDistance(i)) * lpGameTask.GetPlanetGravity(i);
		finalVec += addVec;
	}
	//SetVec(finalVec + vec);
	pos += (vec * (speed));
	//DrawFormatString(50, SCREEN_SIZE_Y / 2, 0xffffff, "vec.x:%.3f,vec.y:%.3f", vec.x, vec.y);
	//DrawFormatString(50, SCREEN_SIZE_Y / 2, 0xffffff, "addVec.x:%.3f,addVec.y:%.3f",addVec.x, addVec.y);
	//DrawFormatString(50, SCREEN_SIZE_Y / 2 + 15, 0xffffff, "test.x:%.3f,test.y:%.3f", test.x, test.y);
}
