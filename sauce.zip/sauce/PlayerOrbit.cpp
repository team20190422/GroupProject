#include "PlayerOrbit.h"
#include "ImageMng.h"

PlayerOrbit::PlayerOrbit(const VECTOR3& DofT,const VECTOR3& pPos):Player(trgKey, oldKey)
{
	insCount++;
	vec = DofT;
	pos = pPos;
}

PlayerOrbit::~PlayerOrbit()
{
	insCount--;
}

void PlayerOrbit::Update()
{
	SetMove();
}

void PlayerOrbit::Draw()
{
	DrawCircle(pos.x, pos.y, 10, 0xffffff, true);
}

void PlayerOrbit::SetMove()
{
	pos += vec;
}

int PlayerOrbit::GetInstanceCnt()
{
	return insCount;
}
