#include "PlayerOrbit.h"
#include "BasePlanet.h"
#include "ImageMng.h"

PlayerOrbit::PlayerOrbit(const VECTOR3& DofT,const VECTOR3& pPos, const float& vy):Player(trgKey, oldKey)
{
	vec = DofT;
	pos = pPos;
	v = vy / 2;
}

PlayerOrbit::~PlayerOrbit()
{
}

const VECTOR3 & PlayerOrbit::GetVec1(void)
{
	return vector;
}

void PlayerOrbit::SetVec1(VECTOR3 vec)
{
	vector = vec;
}

const float & PlayerOrbit::GetOrbDistance(void)
{
	return orbDistance;
}

void PlayerOrbit::SetOrbDistance(float dis)
{
	orbDistance = dis;
}

const VECTOR3 & PlayerOrbit::GetOrbPos(void)
{
	return this->pos;
}

void PlayerOrbit::SetVector(VECTOR3 vec)
{
	this->vec = vec;
}


void PlayerOrbit::Update()
{
	mgn = sqrt((vec.x * vec.x) + (vec.y * vec.y));
	uniVec = vec / mgn;
	SetVec1(vec);

	SetMove();

	planetPos.resize(lpGameTask.planetMax);
	for (int i = 0; i < lpGameTask.planetMax; i++)
	{
		planetPos[i] = lpGameTask.GetPlanetPositon(i);

		float a = planetPos[i].x - pos.x;
		float b = planetPos[i].y - pos.y;
		distance = sqrt((a * a) + (b * b));
		if (distance < distanceMin)
		{
			distanceMin = distance;
			planetPosSave = planetPos[i];
		}
		//DrawFormatString(20, SCREEN_SIZE_Y / 2 + 50 + 15 * i, 0xffffff, "planetX:%.3f,planetY:%.3f,D:%.3f", planetPos[i].x, planetPos[i].y,distanceMin);
	}
	gVec = { planetPosSave.x - pos.x,planetPosSave.y - pos.y };
	EofG = 1.5f;																//�Ƃ肠�����Œ�l
	addVec = AddVec((Obj::Normalize((gVec), distanceMin) * EofG), vec);
	//SetVector(addVec);
}

void PlayerOrbit::Draw()
{
	DrawLine(pos.x, pos.y, planetPosSave.x, planetPosSave.y, 0xff00ff, true);
	DrawCircle(pos.x, pos.y, 2, 0x66B3FF, true);
}

void PlayerOrbit::SetMove()
{
	pos += (vec * v) + addVec;
}
