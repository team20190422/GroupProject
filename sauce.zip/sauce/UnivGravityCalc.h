#pragma once
#include "Obj.h"
#include <vector>
#include "DxLib.h"

class UnivGravityCalc : public Obj
{
public:
	UnivGravityCalc();
	~UnivGravityCalc();

	void AddAstPos(VECTOR3);
	void SetAstPos(int,VECTOR3);
	void AddAstMass(float);
	void SetTgtMass(int i, float m);
	VECTOR3 GravityValue(int i, VECTOR3 pos);
	// M:�f���̎��� m:���@�̎��� r:���̊Ԃ̋��� 
	float UnivGravity(float M, float m, float r);

private:
	std::vector<VECTOR3>astPos;

	std::vector<VECTOR3>PtoPVector;
	std::vector<float>distance;
	std::vector<float>mass;
};

