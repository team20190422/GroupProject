#pragma once
#include "Obj.h"
#include "GameTask.h"
#include <array>

typedef std::shared_ptr<Obj> land_ptr;
typedef std::list<land_ptr> land_List;

constexpr unsigned int parDirMax = 3;

class LandPlayer :
	public Obj
{
public:
	LandPlayer(const int(&trgKey)[KEY_MAX], const int(&oldKey)[KEY_MAX], int stageCnt);
	~LandPlayer();

	void Draw(void);
	void Update(void);
	void SetMove(void);
	void Cinema(void);

private:
	land_List particleList;
	std::list<land_ptr>::iterator particle;


	bool sinFlag = false;
	bool injectionFlag = false;
	bool shieldFlag = true;
	bool separateFlag = false;
	bool skipFlag = false;
	bool particleFlag = false;

	// 0:�����@1:�^���@2:�E��
	std::array<bool, parDirMax> parListFlag = { 0 };

	// ̪��ޱ��
	std::array<float, 3> Fadeout = { 0 };

	int count = 0;
	int colCnt = 1;
	int colTmp = 200;
	int colTmp2 = 200;
	int cupsule = 0;
	int planet = 0;
	int capsuleShield = 0;
	int spCraft = 0;
	int landMap = 0;
	int mapSoft = 0;
	int suiheikei[2] = { 0 };
	int capsulePara[10] = { 0 };
	int capsuleParaL = 0;
	int color = 0;
	int colorPos = 0;
	int animCnt = 0;
	int anim = 0;
	int tmp;
	int RGB[3] = { 154,96,61 + 30 };
	int lrFlag = 0;										// -1:����] 0:�����l 1:�E��]			
	int speedUI = 0;
	int BG = 0;
	int skipCnt = 0;
	int scene = 0;
	int offset = 0;
	int stop = 1;
	int landAngle = 0;									// -1:���s 0:�����l 1:����
	int deg = 0;
	int sepCnt = 0;
	int DieAnim[12] = { 0 };							// ������Ұ���
	int AnimCnt = 0;									// ""
	int AnimTime = 0;									// ""
	int GameLight = 255;								// �Ó]����
	int stageCnt = 0;									// ���݂̽ð�ފm�F
	int distance = 800;									// ����
	int smokeTime = 0;

	float countF = 0.0f;
	float size = 4.0f;
	float vx = 0.0f;
	float vy = 0.0f;
	float vySkip = 0.0f;
	float angle = 0.0f;
	float shieldAngle = 0.0f;
	float paraAngle = 0.0f;
	float spCAngle = 0.0f;
	float spCAngleF = 0.0f;								// spaceCraft�̍ŏI�p�x
	float spCSize = 1.4f;
	float rolInc = 0.0f;
	float speed = 0.0f;
	float mapSize = 3.0f;
	float particleSpeed = 3.0f;
	float alpha = 0.0f;
	struct {
		float l = 0;
		float r = 450;
		float u = 0;
		float d = 0;
	}cineBox1;
	struct {
		float l = 0;
		float r = 450;
		float u = 800;
		float d = 800;
	}cineBox2;

	VECTOR3 motherPos = { 0,0 };
	VECTOR3 cupPos = { 0,0 };
	VECTOR3 shieldPos = { 0,0 };
	VECTOR3 paraPos = { SCREEN_SIZE_X / 2, -100 };
	VECTOR3 mapImageSize = { 150,266};
	VECTOR3 hitPos = { 0,0 };

	VECTOR3 centerPosU = { 0,0 };
	VECTOR3 centerPosD = { 0,0 };

	VECTOR3 spCLine1U = { 0,0 };
	VECTOR3 spCLine2U = { 0,0 };

	VECTOR3 spCLine1D = { 0,0 };
	VECTOR3 spCLine2D = { 0,0 };
	VECTOR3 landingL = { 0,0 };
	VECTOR3 landingR = { 0,0 };
};