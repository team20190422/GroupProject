#include "Dxlib.h"
#include "OrbitPoint.h"
#include "GameTask.h"

OrbitPoint::OrbitPoint(const VECTOR3 & vec, const VECTOR3 & pos, const float & v) : PlayerOrbit(vec, pos, v) 
{
}

OrbitPoint::~OrbitPoint()
{
}

void OrbitPoint::SetPointPos(VECTOR3 pos)
{
	this->pos = pos;
}

void OrbitPoint::Update()
{
	if (alpha >= 0)
	{
		alpha -= 0.5f;
	}
//	DrawFormatString(20, SCREEN_SIZE_Y / 2, 0xffffff, "pos.x:%f,pos.y:%f", pos.x,pos.y);
}

void OrbitPoint::Draw()
{
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
	DrawCircle(pos.x,pos.y,2, 0xfffff, true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
}
