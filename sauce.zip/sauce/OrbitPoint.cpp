#include "Dxlib.h"
#include "OrbitPoint.h"
#include "GameTask.h"

OrbitPoint::OrbitPoint(const VECTOR3 & vec, const VECTOR3 & pos, const float & v) : PlayerOrbit(vec, pos, v) 
{
}

OrbitPoint::~OrbitPoint()
{
}

void OrbitPoint::Update()
{
	DrawFormatString(20, SCREEN_SIZE_Y / 2, 0xffffff, "pos:%f", pos);
}

void OrbitPoint::Draw()
{
}
