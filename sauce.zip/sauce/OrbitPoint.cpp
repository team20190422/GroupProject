#include "Dxlib.h"
#include <vector>
#include "OrbitPoint.h"
#include "GameTask.h"

OrbitPoint::OrbitPoint(const VECTOR3 & vec, const VECTOR3 & pos, const float & v,const int& cnt) : PlayerOrbit(vec, pos, v) 
{
	size = cnt;
	pointPos.resize(size);

}

OrbitPoint::~OrbitPoint()
{
}

void OrbitPoint::SetPointPos(VECTOR3 pos ,int i)
{
	pointPos[i] = pos;
}

const VECTOR3& OrbitPoint::GetPointPos()
{
	return pos;
}



void OrbitPoint::Update()
{
	pointPos.resize(size);

	pos = pointPos[size-1];

	if (alpha >= 0)
	{
		alpha -= 3.0f;
	}
	DrawFormatString(20, SCREEN_SIZE_Y / 2 - 100, 0xffffff, "pos.x:%f,pos.y:%f", pointPos[0].x,pointPos[0].y);

}

void OrbitPoint::Draw()
{
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
	DrawCircle(pos.x,pos.y,2, 0xfffff, true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, alpha);
}
