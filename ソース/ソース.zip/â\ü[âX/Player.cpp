#include "Player.h"



Player::Player(const int(&trgKey)[6], const int(&oldKey)[6]) :Obj(trgKey, oldKey)
{
}


Player::~Player()
{
}
