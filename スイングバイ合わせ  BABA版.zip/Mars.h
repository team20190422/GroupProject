#pragma once
#include "BasePlanet.h"

constexpr unsigned int JupiterMax = 7;

class Mars :
	public BasePlanet
{
public:
	Mars(VECTOR3 pos, int marsCnt);
	~Mars();	
private:
	VECTOR3 mPos = { 0,0 };
	double time = 0;
	int imageCnt = 0;
	int nextPlanet = 0;
	int planetImage = 0;
	int mokutekichi = 0;
	float gravity = 1.5f;
	float size = 0;
	int animCnt = 0;
	double jupiterSize = 1.0;
	float Size = 0;
	int JupiterImage[JupiterMax] = { 0 };
	VECTOR2 imageSize = { 0,0 };

protected:
	void Init();
	void Update();
	void Draw();

};

