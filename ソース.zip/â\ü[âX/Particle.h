#pragma once
#include "Player.h"

class Particle :
	public Player
{
public:
	Particle(const VECTOR3& targetPos, const VECTOR3& targetVec);
	~Particle();

	void Draw(void);
	void Update(void);

	void SetMove(void);

	const int& GetTimer(void);

	int time = 0;

private:
	const int(&trgKey)[6] = { 0 };
	const int(&oldKey)[6] = { 0 };
	std::weak_ptr<Player> target;

	VECTOR3 pos = { 0,0 };
	VECTOR3 vec = { 0,0 };

	int fire;
};

