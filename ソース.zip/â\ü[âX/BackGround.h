#pragma once

//class GameTask;
class BackGround {
public:
	BackGround();
	~BackGround();

	void Update();
	void Draw();
private:
	int randomX;
	int randomY;

};