#include <Dxlib.h>
#include "GameTask.h"
#include "BackGround.h"

BackGround::BackGround():Obj(j, j)
{
	Init();
}

BackGround::~BackGround()
{
}

void BackGround::Init()
{
	count = GameTask::GetInstance().SetCount();
	removeFlag = false;
	randomX = GetRand(SCREEN_SIZE_X);
	if(count <= 300)
	{
		randomY = GetRand(SCREEN_SIZE_Y);
	}
	else
	{
		randomY = GetRand(SCREEN_SIZE_Y) - 800;
	}
	
}

void BackGround::Update()
{
	vy += 0.2f;
	if (randomY + vy > SCREEN_SIZE_Y)
	{
		removeFlag = true;
	}
}

void BackGround::Draw()
{
	//int col = GetRand(255);
	if (randomX % 2 == 0)
	{
		DrawCircle(randomX, randomY + vy, 1, GetColor(255,255,255), true);
	}
	else if(randomX % 3 == 0)
	{
		DrawCircle(randomX, randomY + vy, 2, GetColor(255,255,255), true);
	}	
}
