#include <Dxlib.h>
#include "GameTask.h"
#include "BackGround.h"

BackGround::BackGround()
{
}

BackGround::~BackGround()
{
}

void BackGround::Update()
{
	for (int i = 0; i < 100; i++)
	{
		randomX = GetRand(SCREEN_SIZE_X);
		randomY = GetRand(SCREEN_SIZE_Y);
	}
}

void BackGround::Draw()
{
	DrawPixel(randomX, randomY, 0xffffff);
}
