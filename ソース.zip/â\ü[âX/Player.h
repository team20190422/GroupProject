#pragma once
#include "Obj.h"
#include "KeyMng.h"
class Player :
	public Obj
{
public:
	Player(const int (&trgKey)[6], const int (&oldKey)[6]);
	~Player();

	void Draw(void);
	void Update(void);
private:
	void SetMove(void);

	VECTOR2 pos = { 0,0 };
	double Angle = 0;
};

