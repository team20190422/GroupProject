#pragma once
#include "Obj.h"
#include "KeyMng.h"
#include <array>
#include <list>

typedef std::shared_ptr<Obj> particle_ptr;
typedef std::list<particle_ptr> particle_List;

// ��߰�ނ̍ő�l
constexpr double speedMax = 5.0f;

// �߰è�ق̍ő�l
constexpr unsigned int particleMax = 30;

class Player :
	public Obj
{
public:
	Player(const int (&trgKey)[6], const int (&oldKey)[6]);
	~Player();

	void Draw(void);
	void Update(void);

	double Abstract(double i);
private:
	std::list<particle_ptr>::iterator AddObjlist(particle_ptr && objPtr);

	particle_List particleList;
	std::list<particle_ptr>::iterator particle;

	void SetMove(void);

	VECTOR3 pos = { 0,0 };
	VECTOR3 radianPos = { 0,0 };
	VECTOR3 vec = { 0,-1 };
	MATRIX master = { 0 };
	//int particleTime = 0;
	std::array<int, particleMax> particleTime = { 0 };
	double Angle = 0;
	float speed = 0.5f;
	double count = -3.0f;

};

