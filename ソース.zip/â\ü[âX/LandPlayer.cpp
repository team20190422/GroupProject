#include "LandPlayer.h"
#include "ImageMng.h"


LandPlayer::LandPlayer(const int(&trgKey)[6], const int(&oldKey)[6]) :Obj(trgKey, oldKey)
{
	pos = { (float)SCREEN_SIZE_X / 2, (float)SCREEN_SIZE_Y / 4 };
}


LandPlayer::~LandPlayer()
{
}

void LandPlayer::Draw(void)
{
	DrawRotaGraph(pos.x, pos.y, 1, 0, IMAGE_ID(imageName), true);

}

void LandPlayer::Update(void)
{
}
