#include "Player.h"
#include "ImageMng.h"
#include "GameTask.h"


Player::Player(const int(&trgKey)[6], const int(&oldKey)[6]) :Obj(trgKey, oldKey)
{
	pos = { SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2 };
}


Player::~Player()
{
}

void Player::Draw(void)
{
	DrawRotaGraph(pos.x, pos.y, 1.0, Angle, IMAGE_ID(imageName), true);


}

void Player::Update(void)
{
	SetMove();
}

void Player::SetMove(void)
{
	if (KeyMng::GetInstance().newKey[P1_RIGHT])
	{
		Angle += 0.01f;
	}
	else if (KeyMng::GetInstance().newKey[P1_LEFT])
	{
		Angle -= 0.01f;
	}
}

