#include "Player.h"
#include "ImageMng.h"
#include "GameTask.h"
#include "Particle.h"

Player::Player(const int(&trgKey)[6], const int(&oldKey)[6]) :Obj(trgKey, oldKey)
{
	particleList.clear();

	pos = { (float)SCREEN_SIZE_X / 2, (float)SCREEN_SIZE_Y };
	radianPos = { pos.x,pos.y };
}


Player::~Player()
{
}

void Player::Draw(void)
{
	int mouseX, mouseY;

	GetMousePoint(&mouseX, &mouseY);

	Angle = (double)atan2(radianPos.y - pos.y, radianPos.x - pos.x) + 1.5f;

	radianPos.x = pos.x + (20 * cos(count / 2));
	radianPos.y = pos.y + (20 * sin(count / 2));

	/*VECTOR radian = VTransform(VGet(1, 0, 0), master);
	MATRIX tmp = MGetRotAxis(radian, Angle);
	master = MMult(master, tmp);*/
	DrawFormatStringF(10, 10, GetColor(255, 255, 255), "�p�x�@%f", Angle);
	DrawFormatString(10, 40, GetColor(255, 255, 255), "posX�@%f  posY %f", pos.x , pos.y);
	DrawFormatString(10, 70, GetColor(255, 255, 255), "vecX�@%f  vecY %f", vec.x, vec.y);
	DrawFormatString(10, 100, GetColor(255, 255, 255), "MposX�@%f  MposY %f", mouseX,mouseY);
	DrawFormatString(10, 130, GetColor(255, 255, 255), "RdX�@%f  RdY %f", radianPos.x, radianPos.y);
	DrawFormatString(10, 160, GetColor(255, 255, 255), "speed�@%f", speed);
	DrawFormatString(10, 190, GetColor(255, 255, 255), "time�@%d", particleTime[0]);

	for (auto itr : particleList)
	{
		itr->Draw();
		itr->Update();

	}

	DrawRotaGraph(pos.x, pos.y, 1.0, Angle, IMAGE_ID(imageName), true);
	DrawLine(pos.x-16, pos.y, pos.x + 16, pos.y, GetColor(255, 255, 255), true);
	DrawLine(pos.x, pos.y -16, pos.x, pos.y + 16, GetColor(0, 255, 255), true);
	//DrawCircle(radianPos.x, radianPos.y,10, GetColor(255, 255, 255),true);

}

void Player::Update(void)
{
	SetMove();
}

double Player::Abstract(double i)
{

	return (i < 0 ? -i : i);
}

std::list<particle_ptr>::iterator Player::AddObjlist(particle_ptr && objPtr)
{
	particleList.push_back(objPtr);
	auto itr = particleList.end();
	itr--;
	return itr;
}

void Player::SetMove(void)
{
	/*vec.x = cos(Angle) * vec.x + -sin(Angle) * vec.y;
	vec.y = sin(Angle) * vec.x + cos(Angle) * vec.y;*/

	//VECTOR front = VTransform(VGet(pos.x, pos.y, 1.0f),master);

	if (KeyMng::GetInstance().newKey[P1_SPACE])
	{
		//particleTime++;
		/*if(speed < speedMax)
		speed += 0.1f;*/
		particle = AddObjlist(std::make_shared<Particle>(pos, vec));
		for (float f = 0.0; f < 3.0; f += 0.1)
		{
			particle = AddObjlist(std::make_shared<Particle>(pos, vec*f));
		}

		for (int i = 0; i < particleMax; i++)
		{
			particleTime[i]++;
		}

		/*particle = AddObjlist(std::make_shared<Particle>(pos, VECTOR3(vec.x + 1.5f,vec.y)));
		particle = AddObjlist(std::make_shared<Particle>(pos, VECTOR3(vec.x - 1.5f, vec.y)));*/
	}

	if (KeyMng::GetInstance().newKey[P1_UP])
	{
		if(speed < speedMax)
		speed += 0.02f;
		/*particle = AddObjlist(std::make_shared<Particle>(pos, VECTOR3(vec.x + 1.5f, vec.y)));
		particle = AddObjlist(std::make_shared<Particle>(pos, VECTOR3(vec.x - 1.5f, vec.y)));*/
	}
	if (KeyMng::GetInstance().newKey[P1_DOWN])
	{
		if(speed >= 0.05f)
		speed -= 0.02f;
	}

	vec.x = sin(Angle);
	vec.y = -(cos(Angle));

	pos += vec * speed;

	if (KeyMng::GetInstance().newKey[P1_RIGHT])
	{
		count += 0.12f;
	}
	else if (KeyMng::GetInstance().newKey[P1_LEFT])
	{
		count -= 0.12f;
	}
	for (int i = 0; i < particleMax; i++)
	{
		if (particleList.size() > 0)
		{

			if ((*particle)->GetTimer() > 0 || particleTime[i] > 1)
			{
 				if (!(particleList.empty()))
				{
					//particleTime[i] = 0;
					particleList.pop_front();
				}
			}
		}
		else
		{
			particleTime[i] = 0;
		}
	}
}

