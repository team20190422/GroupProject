#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#define new ::new(_NORMAL_BLOCK, __FILE__, __LINE__)
#include "DxLib.h"
#include "GameTask.h"
#include "Player.h"
#include "LandPlayer.h"
#include "BackGround.h"
#include "Obstracle.h"
#include "BasePlanet.h"
#include "Mars.h"
#include "Earth.h"
#include "Asteroid.h"
#include "Particle.h"
#include "StageSet.h"
//#include"Enemy.h"
//#include "Stage.h"
#include"KeyMng.h"
#include"ImageMng.h"

//
constexpr unsigned int SCREEN_CENTER_X = 200;
constexpr unsigned int SCREEN_CENTER_Y = 300;
constexpr unsigned int StageMax = 3;

GameTask *GameTask::s_Instance = nullptr;
int GameTask::GameUpdate(void)
{
	int rtn_id;
	//�L�[���X�V
	KeyMng::GetInstance().Update();

	rtn_id = (this->*GtskPtr)();

	return rtn_id;
}


int GameTask::SetCount()
{
	return count;
}

bool GameTask::HitCheck(RECT rect1, RECT rect2)
{
	if (rect1.left <= rect2.right &&rect1.top <= rect2.bottom
		&&rect1.right >= rect2.left &&rect1.bottom >= rect2.top) {
		return true;
	}
	else {
		return false;
	}
}

const bool & GameTask::GetHitCheck(void)
{
	return this->hitCheck;
}

void GameTask::SetHitCheck(bool hitCheck)
{
	this->hitCheck = hitCheck;
}

const bool & GameTask::GetLandCheck(void)
{
	return landingCheck;
}

void GameTask::SetLandCheck(bool landing)
{
	landingCheck = landing;
}

const bool & GameTask::GetCupLandCheck(void)
{
	return cupLandingCheck;
}

void GameTask::SetCupLandCheck(bool cupLanding)
{
	cupLandingCheck = cupLanding;
}

const bool & GameTask::GetDarkFlag2(void)
{
	return darkFlag2;
}

void GameTask::SetDarkFlag2(bool dark)
{
	darkFlag2 = dark;
}

const int & GameTask::GetEnergy(void)
{
	return Energy;
}

void GameTask::SetEnergy(int energy)
{
	Energy = energy;
}

const VECTOR3 & GameTask::GetScrollPos(void)
{
	return ScrollPos;
}

void GameTask::SetScrollPos(VECTOR3 addPos)
{
	ScrollPos.y = addPos.y;
}

const float & GameTask::GetRocketSize(void)
{
	return rocketSize;
}

const int & GameTask::GetLandingCnt(int i)
{
	return landingCnt[i];
}

GameTask::GameTask()
{
	//GtskPtr = &GameTask::SystemInit;
	oldKey = 0;
}

GameTask::~GameTask()
{
}

void GameTask::Die(void)
{

}

void GameTask::Create(void)
{
	if (!s_Instance) {
		s_Instance = new GameTask();
	}
}


int GameTask::SystemInit(void)
{
	SetWindowText("�X�C���O�o�C");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);
	ChangeWindowMode(true);
	if (DxLib_Init() == -1) {
		return -1;
	}
	SetDrawScreen(DX_SCREEN_BACK);

	for (int j = 0; j < 11; j++)
	{
		DieAnim[j] = LoadDivGraph("image/Explosion/����_��.png", 11, 11, 1, 115, 100, DieAnim,true);
		OutScrAnim[0][j] = LoadDivGraph("image/Number/countdown.png", 11, 11, 1, 100, 100, OutScrAnim[0], true);
		if (j <= StageMax)
		{
			OutScrAnim[1][j] = LoadDivGraph("image/Number/StageCnt.png", 3, 3, 1, 100, 100, OutScrAnim[1], true);
		}
		//DieAnim[j] = LoadGraph("image/����_��.png");
	}
	for (int i = 0; i < EarthMax; i++)
	{
		EarthImage[i] = LoadDivGraph("image/earthAnimNC.png", 20, 20, 1, 100, 50, EarthImage, true);
	}

	//���y�t�@�C���ǂݍ���
	OP = LoadBGM("sound/���̉F���̂ǂ�����.mp3");
	Main = LoadBGM("sound/�������~���.mp3");
	ED1 = LoadBGM("sound/�V��.ogg");
	ED2 = LoadBGM("sound/farewell.ogg");
	LED = LoadBGM("sound/���E���l�B�ɗh���܂�.ogg");
	Over = LoadBGM("sound/�F�����.ogg");
	Result_rank = LoadBGM("sound/bomb.mp3");
	Result_rankAll = LoadBGM("sound/destruction1.mp3");
	Cheers = LoadBGM("sound/people_people-stadium-cheer1.mp3");
	SetCreateSoundDataType(DX_SOUNDDATATYPE_MEMPRESS);	// ���k���ꂽ�S�f�[�^�̓V�X�e���������Ɋi�[����A�Đ����镔�����������𓀂��Ȃ���T�E���h�������Ɋi�[����(�炵�I���Ɖ𓀂����f�[�^�͔j�������̂ŉ��x���𓀏������s����)
	Decision = LoadSoundMem("sound/�I����.ogg");
	Rocket = LoadSoundMem("sound/���P�b�g����.mp3");
	Engine = LoadSoundMem("sound/�O�C.mp3");
	Boost = LoadSoundMem("sound/�K�X�o�[�i�[.ogg");
	Emergency = LoadSoundMem("sound/�x��.ogg");
	Emergency2 = LoadSoundMem("sound/�x��03.ogg");
	Bom = LoadSoundMem("sound/explosion3.ogg");
	UFO = LoadSoundMem("sound/UFO01.ogg");

	GtskPtr = &GameTask::GameTitle;
	return 0;
}


int GameTask::GameInit(void)
{
	//
	auto riset = [&] {
		time = 0;
		MainTimer = 0;
		AnimCnt = 0;
		clearCnt = 0;
		limitAnimSize = 2.0f;
		limitTime = 4;
		subTitleCnt = 0;
		subTitleAnim = 0;
		outScreenTime = 0;
		resultAnimCnt = 200;
		resultTime = 0;
		overBright = 255.0f;

		clearCheck = false;
		landingCheck = false;
		landingFlag = false;
		returnFlag = false;
		getSample = false;
		subTitleFlag = false;
	};
	//

	objList.clear();
	bpList.clear();
	tSetPos.clear();

	//
	riset();
	//

	for (auto i : targetSet)
	{
		i += VECTOR3(1, 0);

	}
	DrawString(0, 0, "INIT", 0xffff00);

	player = AddObjlist(std::make_shared<Player>(lpKeyMng.trgKey,lpKeyMng.oldKey));
	obstracle = AddObjlist(std::make_shared<Obstracle>());

	earth = AddBplist(std::make_shared<Earth>(VECTOR3(225, SCREEN_SIZE_Y * 2)));

	int AsteroidCnt = 0;
	for (auto planet : stageSet[StageCnt])
	{
		AsteroidCnt++;
		asteroid = AddBplist(std::make_shared<Asteroid>(planet, AsteroidCnt));
	}

	for (auto targetPlanet : targetSet)
	{
		if (targetPlanet == targetSet[StageCnt])
		{
			MarsCnt++;
			mars = AddBplist(std::make_shared<Mars>(targetPlanet, MarsCnt));
		}
	}

	for (auto itr : bpList)
	{
		tSetPos.push_back(itr->GetPos());
	}

	if (UFOFlag == true) {
		(*player)->init("image/UFO.png", VECTOR2(64 / 2, 32 / 1), VECTOR2(2, 1), VECTOR2(1, 0), 1.0f);
	}
	else {
		(*player)->init("image/Player.png", VECTOR2(64 / 2, 32 / 1), VECTOR2(2, 1), VECTOR2(1, 0), 1.0f);
	}
	(*obstracle)->init("image/meteo.png", VECTOR2(64 / 2, 32 / 1), VECTOR2(2, 1), VECTOR2(1, 0), 0.5f);

	//ImageMng::GetInstance().SetID("TITLE", "image/�^�C�g��.png");
	back = new BackGround();

	GtskPtr = &GameTask::GameMain;

	return 0;
}

int GameTask::GameTitle(void)
{
	auto AddPtclist = [&](particle_ptr && objPtr)
	{
		particleList.push_back(objPtr);
		auto itr = particleList.end();
		itr--;
		return itr;
	};


	ClsDrawScreen();

	titleTime++;
	int shakeEarth = GetRand(titleShake);

	if (titleBright < 255)
	{
		titleBright += 2;
		SetDrawBright(titleBright, titleBright, titleBright);
	}


	StageCnt = 0;
	MarsCnt = 0;

	//�T�E���h�֌W
	ChangeVolumeSoundMem(255 * 70 / 100, OP);//OP�̉��̃{�����[����70%�ɐݒ�
	if (CheckSoundMem(OP) == 0)PlaySoundMem(OP, DX_PLAYTYPE_LOOP);//OP���Đ����łȂ���Ή���炷

																  //�B���R�}���h
	if (KeyMng::GetInstance().newKey[P1_LCtrl]) {
		UFOFlag = true;
	}

	DrawGraph(0, 0, ImageMng::GetInstance().SetID("image/landBG.png"), true);
	//if ((lgtsCnt++ / 30) % 2 == 0)
	{
		DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y, 1, angle+=0.005f, ImageMng::GetInstance().SetID("image/LGTS.png"), true);
	}
	DrawGraph(0, 0, ImageMng::GetInstance().SetID("image/title.png"), true);
	DrawRotaGraphF(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y - 100, earthSize, 0, EarthImage[(earthAnimCnt++ / 15) % 19], true);

	// ���ى��
	DrawGraph(0, 0, ImageMng::GetInstance().SetID("image/title.png"), true);
	DrawRotaGraphF(SCREEN_SIZE_X / 2, (SCREEN_SIZE_Y - 100) + shakeEarth, earthSize, 0, EarthImage[(earthAnimCnt++ / 15) % 19], true);

	if (KeyMng::GetInstance().newKey[P1_LCtrl]) {
		UFOFlag = true;
	}
	if (UFOFlag == true) {
		int ufo_x = 25, ufo_y = 200;
		DrawGraph(ufo_x, ufo_y, IMAGE_ID("image/UFO�o��.png"), true);
	}
	//�Q�[�����[�h�ڍs
	if (KeyMng::GetInstance().trgKey[P1_SPACE])
	{
		PlaySoundMem(Decision, DX_PLAYTYPE_BACK);

		titleShake = 5;
		launchFlag = true;

		//pushSpace = true;
	}

	// ̪���
	if (launchFlag)
	{
		soundV.Rocket -= 0.08f;
		ChangeVolumeSoundMem(255 * soundV.Rocket / 100, Rocket);
		if (rocketPos.y < SCREEN_SIZE_Y / 4)
		{
			soundV.OP -= 0.5f;
			ChangeVolumeSoundMem(255 * soundV.OP / 100, OP);
		}
	}


	// �U��
	if (titleShake > 0)
	{
		if (titleTime % 30 == 0)
		{
			titleShake--;
		}
	}

	if (titleShake == 1)
	{
		titleShake = 0;
		pushSpace = true;
	}

	if (pushSpace)
	{
		timeCnt++;
		// ��ݽ����
		if (timeCnt > 1)
		{
			if (KeyMng::GetInstance().trgKey[P1_SPACE])
			{
				skipFlag = true;
			}
		}
		if (!UFOFlag)
		{
			// �߰è�ٍ쐬
			float parMax = 2.0f;
			for (float f = 0.0; f < parMax; f += 0.1)
			{
				particle = AddPtclist(std::make_shared<Particle>(rocketPos, VECTOR3(0, 0), 5));
			}
			for (auto title : particleList)
			{
				title->Draw();
				title->Update();
			}

			// �߰è�ق̍폜
			for (int i = 0; i < particleList.size(); i++)
			{
				if (particleList.size() > 0)
				{

					if (particleList.front()->GetTimer() > 7)
					{

						if (!(particleList.empty()))
						{
							particleList.pop_front();

						}
					}
				}
			}
			// ۹�ĕ`��
			DrawRotaGraph(rocketPos.x, rocketPos.y, rocketSize, 0, ImageMng::GetInstance().SetID("image/rocket.png"), true);
		}
		else
		{
			ufoTime++;
			UFOpos.x += 2;
			/*if (!ufoYflag)
			{
				UFOpos.y--;
			}
			else
			{
				UFOpos.y++;
			}
			if (UFOpos.y <= 440 && !ufoYflag)
			{
				ufoYflag = true;
			}
			else if (UFOpos.y >= 450 && ufoYflag)
			{
				ufoYflag = false;
			}*/
			// ufo�`��
			DrawRotaGraph(UFOpos.x, UFOpos.y - sin(3.1415 * 2 / 100 * ufoTime) * 30, 0.3, 0, ImageMng::GetInstance().SetID("image/ufo(side).png"), true);
		}
		rocketPos.y -= 3.0f;
		if (rocketSize >= 2.0f)
		{
			rocketSize = 2.0f;
		}
		else
		{
			rocketSize += 0.01f;
		}

		if (rocketPos.y < 0 || skipFlag)
		{
			if (landingCnt[0] > 0 && !lightFlag)
			{
				landingCnt[0] -= 5;
			}
			else
			{
				lightFlag = true;
				/*DeleteGraph(ImageMng::GetInstance().SetID("image/rocket.png"));
				DeleteGraph(ImageMng::GetInstance().SetID("image/landBG.png"));
				DeleteGraph(ImageMng::GetInstance().SetID("image/title.png"));
				for (int i = 0; i < 20; i++)
				{
					DeleteGraph(EarthImage[i]);
				}*/
				if (CheckSoundMem(OP) == 1) StopSoundMem(OP);//Title���Đ����Ȃ�Title���~�߂�

				skipFlag = false;
				timeCnt = 0;
				GtskPtr = &GameTask::GameInit;
			}
			/*if (lightFlag)
			{
			if (landingCnt[0] < 255)
			{
			landingCnt[0] += 5;
			}
			else
			{
			GtskPtr = &GameTask::GameInit;
			}
			}*/
		}
		SetDrawBright(landingCnt[0], landingCnt[0], landingCnt[0]);
	}
	//DrawFormatString(0, 500,0xffffff, "pushFlag %d timeCnt %d skipFlag %d", pushSpace,timeCnt,skipFlag);
	ScreenFlip();
	return 0;
}

// �F���V�j
int GameTask::GameMain(void)
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	ClsDrawScreen();

	// �߰�ޗp
	if (KeyMng::GetInstance().trgKey[P1_PAUSE] && !GetHitCheck())
	{
		if (pauseFlag)
		{
			pauseFlag = false;
		}
		else
		{
			pauseFlag = true;
			pauseBrightTime = 255;
		}
	}

	DrawFormatString(10, 600, 0xffffff, "flag %d", pauseFlag);

	if (!pauseFlag)
	{
		// ���ިݸގ��̕���p����ьv��
		MainTimer++;
	}
	else
	{
		if (pauseBrightTime > 100)
		{
			pauseBrightTime -= 5;
		}
		SetDrawBright(pauseBrightTime, pauseBrightTime, pauseBrightTime);
	}

	if (CheckSoundMem(Main) == 0)PlaySoundMem(Main, DX_PLAYTYPE_LOOP);//Main���Đ����łȂ���Ή���炷

																	  //�T�E���h�֌W
																	  //�T�E���h�֌W
	if (KeyMng::GetInstance().newKey[P1_UP]) {//���L�[�������ꂽ�Ƃ�
		if (UFOFlag == true)
		{
			if (CheckSoundMem(UFO) == 0)PlaySoundMem(UFO, DX_PLAYTYPE_LOOP);//UFO���Đ����łȂ���Ή���炷
		}
		else
		{
			//���P�b�g���˂̉����Đ����łȂ���΃��P�b�g���˂̉����Đ�����
			ChangeVolumeSoundMem(255 * soundV.Engine - soundVol / 100, Engine);
			if (CheckSoundMem(Engine) == 0)PlaySoundMem(Engine, DX_PLAYTYPE_LOOP);//Engine���Đ����łȂ���Ή���炷
		}
	}
	else
	{	//�����łȂ���Ή����~�߂�
		StopSoundMem(UFO);//UFO�����~�߂�
		StopSoundMem(Engine);//Rocket�����~�߂�
		StopSoundMem(Rocket);//Rocket�����~�߂�
		if (soundVol <= 100)
		{
			soundVol++;
		}
		ChangeVolumeSoundMem(255 * soundV.Engine - soundVol / 100, Engine);
	}

	if (KeyMng::GetInstance().oldKey[P1_UP])
	{
		soundV.Engine--;
	}
	else
	{
		soundV.Engine = 100;
	}

	if (KeyMng::GetInstance().newKey[P1_SPACE]) {
		if (CheckSoundMem(Boost) == 0)PlaySoundMem(Boost, DX_PLAYTYPE_BACK);//Boost���Đ����łȂ���Ή���炷
	}
	else {
		StopSoundMem(Boost);//Boost�����~�߂�
	}


	// ��������
	auto StageDraw = [&] {
		SetFontSize(60);
		ChangeFont("Ailerons");

		if (!subTitleFlag)
		{
			if (subTitleCnt < 255)
			{
				subTitleCnt += 5;
			}
			else
			{
				subTitleAnim++;
				if (subTitleAnim > 60)
				{
					subTitleFlag = true;
				}
			}
			SetDrawBlendMode(DX_BLENDMODE_ALPHA, subTitleCnt);

			//DrawFormatString(SCREEN_CENTER_X - SCREEN_SIZE_X / 4, SCREEN_CENTER_Y, GetColor(subTitleCnt, subTitleCnt, subTitleCnt), "STAGE");
			//SetDrawBright(subTitleCnt, subTitleCnt, subTitleCnt);
			DrawRotaGraph(SCREEN_CENTER_X, SCREEN_CENTER_Y + 25, 0.8, 0, IMAGE_ID("image/Number/stage.png"), true);
			DrawRotaGraph(SCREEN_CENTER_X + SCREEN_SIZE_X / 4, SCREEN_CENTER_Y + 25, 0.8, 0, OutScrAnim[1][StageCnt], true);
			//SetDrawBright(255, 255, 255);
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

		}
		else
		{
			if (subTitleCnt > 0)
			{
				subTitleCnt -= 5;
				//DrawFormatString(SCREEN_CENTER_X - SCREEN_SIZE_X / 4, SCREEN_CENTER_Y, GetColor(subTitleCnt, subTitleCnt, subTitleCnt), "STAGE");
				SetDrawBlendMode(DX_BLENDMODE_ALPHA, subTitleCnt);
				//SetDrawBright(subTitleCnt, subTitleCnt, subTitleCnt);
				DrawRotaGraph(SCREEN_CENTER_X, SCREEN_CENTER_Y + 25, 0.8, 0, IMAGE_ID("image/Number/stage.png"), true);
				DrawRotaGraph(SCREEN_CENTER_X + SCREEN_SIZE_X / 4, SCREEN_CENTER_Y + 25, 0.8, 0, OutScrAnim[1][StageCnt], true);
				//SetDrawBright(255, 255, 255);
				SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
			}
			else
			{

			}
		}
		ChangeFont("MS�S�V�b�N");

		SetFontSize(20);		// ̫�Ă̻���

	};

	auto GameOver = [&] {

		if (GetHitCheck())
		{
			if (landingCnt[0] > 0)
			{
				landingCnt[0] -= 15;
				return true;
			}
			else
			{
				GtskPtr = &GameTask::GameOver;
				return true;
			}
		}
		
		SetDrawBright(landingCnt[0], landingCnt[0], landingCnt[0]);

		return false;
	};
	// �����܂�

	if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		PlaySoundMem(Decision, DX_PLAYTYPE_BACK);
		if (CheckSoundMem(Main) == 1) {	//Main���Đ����Ȃ�
			StopSoundMem(Main);	////�������ɓǂݍ���Main�̉��f�[�^���폜
			StopSoundMem(Rocket);// Rocket���Đ����Ȃ�Rocket�̉����~�߂�
			StopSoundMem(Boost);// Boost���Đ����Ȃ�Boost�̉����~�߂�
			StopSoundMem(Emergency2);
		}

		landingCheck = false;
		GtskPtr = &GameTask::GameResult;
	}

	std::vector<BackGround*>::iterator itrBG = backVec.begin();


	if (count <= 300)
	{
		count++;
		back = new BackGround();
		backVec.push_back(back);
		BackGraundCnt++;

	}
	else if (count > 300 && count <= 600)
	{
		count++;
		back = new BackGround();
		backVec.push_back(back);
		BackGraundCnt++;

	}

	for (auto itrBG : backVec)
	{
		if (!pauseFlag)
		{
			itrBG->Update();
		}
		itrBG->Draw();
	}

	distance = { DISTANCE_MAX };
	
	if (!pauseFlag)
	{
		time++;
	}
	for (auto itr : bpList)
	{

		// ���ׂĂ̘f����Update
		if (!GetHitCheck() || time < 10)
		{
			if (!pauseFlag)
			{
				itr->Update();
			}
		}

		itr->Draw();

		if (!clearCheck)
		{
			targetDistance = (*mars)->GetDistance();
		}
		else
		{
			targetDistance = (*earth)->GetDistance();
		}
		if (itr->GetDistance() < distance)
		{

			PandPvec = itr->GetVec();
			if (itr->GetDistance() > 0)
			{
				distance = itr->GetDistance();
				gravity = itr->GetGravity();

			}
		}

	}

	for (auto itr : objList)
	{
		//(*player)->GetPos();
		playerPos = (*player)->GetPos();
		playerAngle = (*player)->GetAngle();
		playerVec = (*player)->GetVec();

		itr->Draw();

		if (!GetHitCheck() && !pauseFlag)
		{
			itr->Update();

		}
		else
		{
			if (!pauseFlag)
			{
				//itr->SetVec(VECTOR3(0, 0));
				if (AnimTime++ % 10 == 0)
				{
					AnimCnt++;
				}
				//DrawBox(playerPos.x, playerPos.y, playerPos.x + 200, playerPos.y + 200, 0xffffff, true);
				DrawRotaGraph((int)playerPos.x, (int)playerPos.y, 1.0, 0, DieAnim[AnimCnt], true);
				//DrawString((int)playerPos.x, (int)playerPos.y, "���ꂽ", 0xffffff);
				StopSoundMem(UFO);		//UFO�����~�߂�
				StopSoundMem(Rocket);	//Rocket�����~�߂�
				StopSoundMem(Boost);	//Boost�����~�߂�
				if (CheckSoundMem(Bom) == 0)PlaySoundMem(Bom, DX_PLAYTYPE_BACK);//�����������Ă��邩���ׂĂȂ��Ă��Ȃ�������炷
																				// ������if��
				if (AnimCnt >= 11)
				{
					GameOver();
				}
			}
		}
		
		if (landingCheck && landingFlag)
		{
			SetHitCheck(false);

			
		}
	}
	// �w�i�̍폜
	itrBG = backVec.begin();
	while (itrBG != backVec.end())
	{
		if ((*itrBG)->removeFlag == true)
		{
			count--;
			delete(*itrBG);
			itrBG = backVec.erase(itrBG);
			BackGraundCnt--;

			break;
		}
		else
		{
			itrBG++;
		}
	}

	//��`�̓����蔻��
	if (HitCheck((*player)->GetRect(), (*obstracle)->GetRect()) == true) {
		hitCheck = true;
		if (GetLandCheck()) {
			hitCheck = false;
		}
	}

	if (hitCheck == true) {	//�v���C���[�����񂾂Ƃ�
		StopSoundMem(UFO);		//UFO�����~�߂�
		StopSoundMem(Rocket);	//Rocket�����~�߂�
		StopSoundMem(Boost);	//Boost�����~�߂�
								//���������Đ����łȂ���Δ��������Đ�����
		if (AnimTime++ % 10 == 0)
		{
			AnimCnt++;
		}
		DrawRotaGraph((int)playerPos.x, (int)playerPos.y, 1.0, 0, DieAnim[AnimCnt], true);
		if (CheckSoundMem(Bom) == 0)PlaySoundMem(Bom, DX_PLAYTYPE_BACK);//Bom���Đ����łȂ���Ή���炷
		if (AnimCnt >= 11)
		{
			GameOver();
		}
	}
	else {
		StopSoundMem(Bom);	//Bom�����~�߂�
	}

	// ����������
	if (landingCheck && landingFlag)
	{
		if (landingCnt[0] > 0)
		{
			landingCnt[0] -= 25;
		}
		else
		{
			setScrPos = false;
			if (landingCheck && landingFlag && !clearCheck)
			{
				// �����Ɉڍs
				//pltrgScr = ScrollPos;
				setScrPos = true;
				setplPos = (*player)->GetplPos();
				/*for (auto itr : bpList)
				{
					tSetPos.push_back(itr->GetPos());
				}*/
				GtskPtr = &GameTask::GameLandInit;
			}
			
		}

		if (landingCnt[0] <= 100)
		{
			// Я��ݸر
			if (returnFlag && clearCheck && landingCheck && landingFlag)
			{
				auto SaveGameMain = SaveDrawScreenToPNG(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, "image/Screen/screen.png", 0);
				resultAnim = LoadGraph("image/Screen/screen.png");

				// Я��ݸر
				GtskPtr = &GameTask::GameResult;
			}
		}
		SetDrawBright(landingCnt[0], landingCnt[0], landingCnt[0]);
	}
	else
	{
		// ����
		if (landingCnt[0] < 255 && !GetHitCheck())
		{
			landingCnt[0] += 20;
		}

		SetDrawBright(landingCnt[0], landingCnt[0], landingCnt[0]);
	}
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 50);
	DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y, 0.9, 0, ImageMng::GetInstance().SetID("image/����.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X / 2, 0, 0.9, 0, ImageMng::GetInstance().SetID("image/����.png"), true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

	// ��������
	// ���@�̉�ʊO��
	if (OutOfScreen && !pauseFlag)
	{
		SetDrawBright(landingCnt[1] + 50, landingCnt[1] + 50, landingCnt[1] + 50);

		for (int x = 0; x < SCREEN_SIZE_X; x++)
		{
			for (int y = 0; y < SCREEN_SIZE_Y; y++)
			{
				auto randomY = GetRand(10000);

				DrawPixel(x, y + randomY, GetColor(255, 255, 255));
			}
		}

		
			if (landingCnt[1] > 0 && (outScreenTime++ % 60) == 0)
			{
				landingCnt[1] -= 20;
				limitTime++;
				if (CheckSoundMem(Emergency2) == 0)PlaySoundMem(Emergency2, DX_PLAYTYPE_BACK);

			}
			SetDrawBright(landingCnt[1], landingCnt[1], landingCnt[1]);
	}
	else
	{
		if (!pauseFlag)
		{
			limitTime = 4;
			limitAnimSize = 2.0f;
			outScreenTime = 0;
		}
		if (Energy >= 20 && landingCnt[1] < 255 && landingCnt[0] >= 255)
		{
			landingCnt[1] += 10;
			SetDrawBright(landingCnt[1], landingCnt[1], landingCnt[1]);
			if (CheckSoundMem(Emergency2) == 1)StopSoundMem(Emergency2);

		}
	}

	// �R�����ʎ�
	if (Energy > 0 && Energy < 20 && !(landingCheck && landingFlag) && !pauseFlag)
	{
		if (landingCnt[1] > 0 && !energyAnim)
		{
			landingCnt[1] -= 10;
			PlaySoundMem(Emergency, DX_PLAYTYPE_BACK);

		}
		else
		{
			energyAnim = true;
		}

		if (landingCnt[1] < 255 && energyAnim)
		{
			landingCnt[1] += 10;
		}
		else
		{
			energyAnim = false;
		}
		SetDrawBright(255, landingCnt[1], landingCnt[1]);
	}

	if (Energy <= 0 && !(landingCheck && landingFlag) && !pauseFlag)
	{
		if (GameOverTime++ > 60)
		{
			if (landingCnt[1] > 0)
			{
				landingCnt[1] -= 10;
			}
			else if(landingCnt[1] <= 5)
			{
				ClsDrawScreen();
				StopSoundMem(Emergency);
				GtskPtr = &GameTask::GameOver;
				GameOverTime = 0;
			}
			SetDrawBright(landingCnt[1], landingCnt[1], landingCnt[1]);


		}
	}
	// �����܂�
	

	if (clearCheck)
	{
		clearCnt++;
	}
	if (AnimCnt >= 10)
	{
		AnimCnt = 10;
	}

	// �����������̑����̖��G����
	if (clearCheck && (landingCheck || landingFlag))
	{
		if (clearCnt < 60)
		{
			SetHitCheck(false);
		}
		else
		{
			//clearCnt = 0;
		}
	}

	// ��������
	if (OutOfScreen && !pauseFlag)
	{

		//SetFontSize(limitAnimSize--);
		limitAnimSize -= 0.033f;
		if(limitTime > 10)
		SetDrawBright(255, 255, 255);
		//DrawFormatString(SCREEN_CENTER_X, SCREEN_CENTER_Y, GetColor(255, 255, 255), "%d", limitTime);
		DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, limitAnimSize, 0, OutScrAnim[0][limitTime], true);
		SetDrawBright(landingCnt[1], landingCnt[1], landingCnt[1]);
		SetFontSize(20);		// ̫�Ă̻���

		if (limitTime >= 10)
		{
			if (landingCnt[1] > 0)
			{
				landingCnt[1] -= 10;
			}
			else
			{

				if (GameOverTime++ > 60)
				{
					ClsDrawScreen();
					GtskPtr = &GameTask::GameOver;
					GameOverTime = 0;
				}
			}

			SetDrawBright(landingCnt[1], landingCnt[1], landingCnt[1]);
		}
	}

	if (limitAnimSize <= 0)
	{
		limitAnimSize = 2.0f;
	}

	

	// �ð�޶���
	if (!getSample)
	{
		StageDraw();
	}

	// �����܂�
	/*DrawFormatStringF(10, 550, GetColor(255, 255, 255), "playerX %f playerY %f", pltrgScr.x, pltrgScr.y);
	DrawFormatStringF(10, 600, GetColor(255, 255, 255), "playerVecX %f playerVecY %f", ScrollPos.x, ScrollPos.y);*/
	//DrawFormatStringF(10, 500, GetColor(255, 255, 255), "���� %d flag %d hit %d", landingCheck, landingFlag, hitCheck);

	/*DrawFormatStringF(10, 500, GetColor(255, 255, 255), "playerPosX %f playerPosY %f", playerPos.x,playerPos.y);
	DrawFormatStringF(10, 550, GetColor(255, 255, 255), "targetVecX %f targetVecY %f", targetVec.x, targetVec.y);
	DrawFormatStringF(10, 600, GetColor(255, 255, 255), "time %d", MainTimer);
	DrawFormatString(10, 650, 0xffffff, "GetLandingCnt1 %d", landingCnt[0]);*/
	ScreenFlip();

	return 0;
}

int GameTask::GameLandInit(void)
{
	landPlayer = AddObjlist(std::make_shared<LandPlayer>(lpKeyMng.trgKey, lpKeyMng.oldKey, StageCnt));

	(*landPlayer)->init("image/playerBeforeLanding.png", VECTOR2(44 / 1, 22 / 1), VECTOR2(1, 1), VECTOR2(0, 0), 1.0f);


	GtskPtr = &GameTask::GameLanding;

	return 0;
}

int GameTask::GameLanding(void)
{
 	StopSoundMem(Emergency);//Emergency�����~�߂�

	ClsDrawScreen();
	if (GetLandCheck())
	{
		if (landingCnt[0] < 255)
		{
			landingCnt[0] += 20;
		}
		else
		{
			SetLandCheck(false);
		}
	}

	if (GetCupLandCheck() && darkFlag == false)
	{
		if (landingCnt[0] > 0)
		{
			landingCnt[0] -= 20;
		}
		else
		{
			darkFlag = true;
		}
	}

	if (darkFlag == true && !GetDarkFlag2())
	{
		if (landingCnt[0] < 255)
		{
			landingCnt[0] += 20;
		}
	}

	if (GetDarkFlag2())
	{
		if (landingCnt[0] > 0)
		{
			landingCnt[0] -= 20;
		}
		else
		{
			SetDarkFlag2(false);
		}
	}

	for (auto itr : objList)
	{
		(*landPlayer)->Draw();
		(*landPlayer)->Update();
	}

	SetDrawBright(landingCnt[0], landingCnt[0], landingCnt[0]);

	int a = GetLandCheck();
	int b = GetCupLandCheck();
	int c = darkFlag;
	//DrawString(0, 0, "GameLanding", 0xffffff);
	DrawFormatString(0, 80, 0xffffff, "%d", a);
	DrawFormatString(0, 95, 0xffffff, "%d", b);
	DrawFormatString(0, 110, 0xffffff, "%d", c);

	if (KeyMng::GetInstance().trgKey[P1_SPACE])
	{
		//landAnimFlag = true;
	}

	// �����B��������F���֖߂�
	if (landAnimFlag)
	{
		pltrgPos = VECTOR3(playerPos.x + targetVec.x, playerPos.y);
		//setplPos = pltrgPos;
		(*player)->SetPos(pltrgPos);
		SetScrollPos(-targetVec);
		pltrgVec = targetVec;
		setCount = true;
		landingCheck = false;
		landAnimFlag = false;
		landingFlag = true;
		clearCheck = true;						// �ر�\��Ԃɂ���
		darkFlag = false;
		darkFlag2 = false;
		pushSpace = false;
		lightFlag = false;
		cupLandingCheck = false;			// ��߾ق�size��0�ɂȂ������׸�
		checkCnt = 0;
		//pltrgPos = { 0,0 };
		landingCnt[0] = 0;
		landingCnt[1] = 255;
		SetDrawBright(landingCnt[0], landingCnt[0], landingCnt[0]);
		if (objList.size() > 0)
		{
			objList.pop_back();
		}
		GtskPtr = &GameTask::GameMain;
	}

	// ����������ްѵ��ް
	if (landGameCheck)
	{
		ClsDrawScreen();
		landingCnt[0] = 0;
		GtskPtr = &GameTask::GameOver;
	}
	ScreenFlip();
	return 0;
}

int GameTask::GameResult(void)
{
	auto Evaluation = [&] {

		// ��ѕ]��
		if (MainTimer <= 200)
		{
			timeEval = 3;
		}
		else if (MainTimer <= 400)
		{
			timeEval = 2;
		}
		else
		{
			timeEval = 1;
		}

		// �R���c�]��
		if (GetEnergy() >= 30)
		{
			fuelEval = 3;
		}
		else if (GetEnergy() >= 20)
		{
			fuelEval = 2;
		}
		else
		{
			fuelEval = 1;
		}

		// �c�@�]��

		// ����
		all = timeEval + fuelEval + lifeEval;

	};

	auto ResultReset = [&] {
		//Line
		line.count1 = 0;
		line.count2 = 0;
		line.count3 = 0;
		line.L = 20.0f;
		line.R1 = 20.0f;
		line.R2 = 20.0f;
		line.R3 = 20.0f;
		line.end = false;

		// rankSize
		rankSize.time = 0.0f;
		rankSize.sample = 0.0f;
		rankSize.life = 0.0f;
		rankSize.all = 0.0f;
		rankSize.incEnd = false;
		rankSize.count = 0;
		rankSize.countSave = 0;
	};

	ClsDrawScreen();
	int imageX = 0, imageY = 0;
	// �摜�̻��ގ擾
	GetGraphSize(ImageMng::GetInstance().SetID("image/Result/�Î�2.png"), &imageX, &imageY);
	if (resultAnimCnt > 0)
	{
		if (resultTime++ % 200 <= 8)
		{
			resultAnimCnt -= 20;
		}
		else
		{
			resultAnimCnt--;
		}
	}

	if (landingCnt[0] < 255)
	{
		landingCnt[0] += 20;
	}
	DrawGraph(0, 0, resultAnim, true);


	SetDrawBright(landingCnt[0], landingCnt[0], landingCnt[0]);



	if (!getSample)
	{
		DrawRotaGraph((SCREEN_SIZE_X - (imageX / 2)) + resultAnimCnt, SCREEN_SIZE_Y - imageY / 2 + 50, 1.0, 0, ImageMng::GetInstance().SetID("image/Result/�Î�2.png"), true);
	}
	else
	{
		DrawRotaGraph((SCREEN_SIZE_X - (imageX / 2)), SCREEN_SIZE_Y - imageY / 2 + 50, 1.0, 0, ImageMng::GetInstance().SetID("image/Result/�g2.png"), true);
		DrawRotaGraph((SCREEN_SIZE_X - (imageX / 2)) + resultAnimCnt, SCREEN_SIZE_Y - imageY / 2 + 50, 1.0, 0, ImageMng::GetInstance().SetID("image/Result/����2.png"), true);
	}
	DrawRotaGraph((SCREEN_SIZE_X - (imageX / 2)), SCREEN_SIZE_Y - imageY / 2 + 50, 1.0, 0, ImageMng::GetInstance().SetID("image/Result/�g.png"), true);

	// �]��
	Evaluation();

	//�T�E���h
	if (CheckSoundMem(Rocket) == 1)StopSoundMem(Rocket);// Rocket���Đ����Ȃ�Rocket�̉����~�߂�
	if (CheckSoundMem(Boost) == 1)StopSoundMem(Boost);// Boost���Đ����Ȃ�Boost�̉����~�߂�
	StopSoundMem(Bom);	// Bom���Đ����Ȃ�Bom�̉����~�߂�
	if (CheckSoundMem(Main) == 1)StopSoundMem(Main);// Main���Đ����Ȃ�Main�̉����~�߂�
	if (CheckSoundMem(Emergency) == 1)StopSoundMem(Emergency);//Emergency�����Đ����Ȃ�Emergency�����~�߂�

	SetFontSize(50);		// ̫�Ă̻���
	SetFontThickness(8);	// ̫�Ă̑���
	ChangeFont("Ailerons");
	//DrawString(SCREEN_SIZE_X / 2 - SCREEN_SIZE_X / 4, SCREEN_SIZE_Y / 2, "RESULT", 0xffffff);
	//DrawFormatStringF(10, 450, GetColor(255, 255, 255), "time   %d %c", MainTimer, timeEval);
	//DrawFormatStringF(10, 500, GetColor(255, 255, 255), "sample %d %c", getSample, sampleEval);//Evaluation
	//DrawFormatStringF(10, 600, GetColor(255, 255, 255), "Evaluation %d", getSample);
	//SetFontSize(20);		// ̫�Ă̻���
	//SetFontThickness(8);	// ̫�Ă̑���
	//ChangeFont("MS�S�V�b�N");

	// ��ver
	DrawRotaGraph(SCREEN_SIZE_X / 2, 50, 1.5, 0, ImageMng::GetInstance().SetID("image/result_kana.png"), true);
	DrawRotaGraph(100, 125, 1, 0, ImageMng::GetInstance().SetID("image/time_kana.png"), true);
	DrawRotaGraph(150, 200, 1, 0, ImageMng::GetInstance().SetID("image/nenryo_kana.png"), true);
	DrawRotaGraph(100, 275, 1, 0, ImageMng::GetInstance().SetID("image/life_kana.png"), true);
	DrawRotaGraph(100, SCREEN_SIZE_Y / 2, 1, 0, ImageMng::GetInstance().SetID("image/rank_kana.png"), true);


	// ��̧�ޯ�ver
	//DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 1.5, 0, ImageMng::GetInstance().SetID("image/result_eng.png"), true);
	//DrawRotaGraph(100, 500, 1, 0, ImageMng::GetInstance().SetID("image/time_eng.png"), true);
	//DrawRotaGraph(100, 600, 1, 0, ImageMng::GetInstance().SetID("image/sample_eng.png"), true);
	// �]��
	rankSize.count++;
	if (rankSize.count > 20)
	{
		line.count1++;
		if (rankSize.time < 1.1f)
		{
			rankSize.time += 0.035f;
		}
		else
		{
			if (rankSize.countSave == 0)
			{
				rankSize.countSave = rankSize.count;
				PlaySoundMem(Result_rank, DX_PLAYTYPE_BACK);
			}
		}

		if (line.R1 < 430)
		{
			line.R1 = line.count1 * 15;
		}
		else
		{
			if (line.R2 < 430)
			{
				line.R2 = line.count2 * 15;
			}
		}
		if (line.R2 > 430)
		{
			if (line.R3 < 430)
			{
				line.R3 = line.count3 * 15;
			}
		}
		DrawBox(line.L, 155, line.R1, 158, 0xffffff, true);
		DrawBox(line.L, 230, line.R2, 233, 0xffffff, true);
		DrawBox(line.L, 305, line.R3, 308, 0xffffff, true);
		if (rankSize.count + 20 < rankSize.countSave * 2)
		{
			line.count2++;
			if (rankSize.sample < 1.1f)
			{
				rankSize.sample += 0.035f;
			}
			else
			{
				PlaySoundMem(Result_rank, DX_PLAYTYPE_BACK);
			}
		}
		else if (rankSize.count + 40 < rankSize.countSave * 3)
		{
			line.count3++;
			if (rankSize.life < 1.1f)
			{
				rankSize.life += 0.035f;
			}
			else
			{
				rankSize.incEnd = true;
				PlaySoundMem(Result_rank, DX_PLAYTYPE_BACK);
			}
		}
		if (rankSize.incEnd)
		{
			if (rankSize.all < 1.5f)
			{
				rankSize.all += 0.03f;
			}
			else
			{
				ChangeVolumeSoundMem(255 * 80 / 100, Result_rankAll);
				PlaySoundMem(Result_rankAll, DX_PLAYTYPE_BACK);
				PlaySoundMem(Cheers, DX_PLAYTYPE_BACK);
				rankSize.incEnd = false;
			}
		}
	}
	if (timeEval == 3)
	{
		DrawRotaGraph(400, 125, rankSize.time, 0, ImageMng::GetInstance().SetID("image/rank_A.png"), true);
	}
	else if (timeEval == 2)
	{
		DrawRotaGraph(400, 125, rankSize.time, 0, ImageMng::GetInstance().SetID("image/rank_B.png"), true);
	}
	else
	{
		DrawRotaGraph(400, 125, rankSize.time, 0, ImageMng::GetInstance().SetID("image/rank_C.png"), true);
	}

	if (fuelEval == 3)
	{
		DrawRotaGraph(400, 200, rankSize.sample, 0, ImageMng::GetInstance().SetID("image/rank_A.png"), true);
	}
	else if (fuelEval == 2)
	{
		DrawRotaGraph(400, 200, rankSize.sample, 0, ImageMng::GetInstance().SetID("image/rank_B.png"), true);
	}
	else
	{
		DrawRotaGraph(400, 200, rankSize.sample, 0, ImageMng::GetInstance().SetID("image/rank_C.png"), true);
	}

	if (lifeEval == 3)
	{
		DrawRotaGraph(400, 275, rankSize.life, 0, ImageMng::GetInstance().SetID("image/rank_A.png"), true);
	}
	else if (lifeEval == 2)
	{
		DrawRotaGraph(400, 275, rankSize.life, 0, ImageMng::GetInstance().SetID("image/rank_B.png"), true);
	}
	else
	{
		DrawRotaGraph(400, 275, rankSize.life, 0, ImageMng::GetInstance().SetID("image/rank_C.png"), true);
	}

	if (all == 9 || all == 8)
	{
		DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, rankSize.all, 0, ImageMng::GetInstance().SetID("image/rank_A.png"), true);
		if (all == 9)
		{
			DrawRotaGraph(SCREEN_SIZE_X / 2 + 50, SCREEN_SIZE_Y / 2, rankSize.all, 0, ImageMng::GetInstance().SetID("image/+.png"), true);
		}
	}
	else if (all == 7 || all == 6)
	{
		DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, rankSize.all, 0, ImageMng::GetInstance().SetID("image/rank_B.png"), true);
		if (all == 7)
		{
			DrawRotaGraph(SCREEN_SIZE_X / 2 + 50, SCREEN_SIZE_Y / 2, rankSize.all, 0, ImageMng::GetInstance().SetID("image/+.png"), true);
		}
	}
	else if (all == 5 || all == 4)
	{
		DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, rankSize.all, 0, ImageMng::GetInstance().SetID("image/rank_C.png"), true);
		if (all == 5)
		{
			DrawRotaGraph(SCREEN_SIZE_X / 2 + 50, SCREEN_SIZE_Y / 2, rankSize.all, 0, ImageMng::GetInstance().SetID("image/+.png"), true);
		}
	}
	else
	{
		DrawRotaGraph(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, rankSize.all, 0, ImageMng::GetInstance().SetID("image/rank_D.png"), true);
	}

	static int count = 0;
	int Clear_X = 0, Clear_Y = 680;

	//if (StageCnt == 0) {
	//	if (CheckSoundMem(ED1) == 0)PlaySoundMem(ED1, DX_PLAYTYPE_LOOP);//Result���Đ����łȂ���Ή���炷
	//	count = (count + 1) % 100;
	//	if (count < 50) {
	//		DrawGraph(Clear_X, Clear_Y, IMAGE_ID("image/Result/Stage1Clear.png"), true);
	//	}
	//}
	//else if (StageCnt == 1) {
	//	if (CheckSoundMem(ED2) == 0)PlaySoundMem(ED2, DX_PLAYTYPE_LOOP);//Result���Đ����łȂ���Ή���炷
	//	count = (count + 1) % 100;
	//	if (count < 50) {
	//		DrawGraph(Clear_X, Clear_Y, IMAGE_ID("image/Result/Stage2Clear.png"), true);
	//	}
	//}
	//else if (StageCnt == 2) {
	//	ChangeVolumeSoundMem(255 * 70 / 100, LED);//LED�̉��̃{�����[����70%�ɐݒ�
	//	if (CheckSoundMem(LED) == 0)PlaySoundMem(LED, DX_PLAYTYPE_LOOP);//Result���Đ����łȂ���Ή���炷
	//	count = (count + 1) % 100;
	//	if (count < 50) {
	//		DrawGraph(Clear_X, Clear_Y, IMAGE_ID("image/Result/Stage3Clear.png"), true);
	//	}
	//}


	if (KeyMng::GetInstance().trgKey[P1_SPACE])
	{
		/*time = 0;
		AnimCnt = 0;
		clearCnt = 0;
		clearCheck = false;
		landingCheck = false;
		landingFlag = false;
		returnFlag = false;
		getSample = false;*/
		StageCnt++;
		ResultReset();
		PlaySoundMem(Decision, DX_PLAYTYPE_BACK);

		if (CheckSoundMem(ED1) == 1)StopSoundMem(ED1);	// ED1���Đ����Ȃ�Ed1�̉����~�߂�
		if (CheckSoundMem(ED2) == 1)StopSoundMem(ED2);	// ED1���Đ����Ȃ�Ed1�̉����~�߂�

		if (CheckSoundMem(LED) == 1)StopSoundMem(LED);	// LED���Đ����Ȃ�LED�̉����~�߂�

		MaxTime = MaxTime + MainTimer;
		GtskPtr = &GameTask::GameInit;
		if (StageCnt == StageMax)
		{
			titleBright = 0;
			rocketSize = 0.0f;
			rocketPos = { SCREEN_SIZE_X / 2,SCREEN_SIZE_Y - 150 };
			lightFlag = false;
			pushSpace = false;
			UFOFlag = false;

			GtskPtr = &GameTask::GameClear;
		}
	}
	//DrawFormatStringF(10, 500, GetColor(255, 255, 255), "���� %d flag %d return %d clear %d sample %d", landingCheck, landingFlag, returnFlag, clearCheck, getSample);
	//DrawFormatStringF(10, 550, GetColor(255, 255, 255), "time %d", MainTimer);
	//DrawFormatStringF(10, 600, GetColor(255, 255, 255), "MaxTime %d", MaxTime);
	ScreenFlip();

	return 0;
}

int GameTask::GameOver(void)
{
	ClsDrawScreen();
	//�T�E���h
	if (CheckSoundMem(Rocket) == 1)StopSoundMem(Rocket);// Rocket���Đ����Ȃ�Rocket�̉����~�߂�
	if (CheckSoundMem(Bom) == 1)StopSoundMem(Bom);// Bom���Đ����Ȃ�Bom�̉����~�߂�
	if (CheckSoundMem(Main) == 1)StopSoundMem(Main);// Main���Đ����Ȃ�Main�̉����~�߂�
	if (CheckSoundMem(Emergency) == 1)StopSoundMem(Emergency);//Emergency�����Đ����Ȃ�Emergency�����~�߂�
	if (CheckSoundMem(Emergency2) == 1)StopSoundMem(Emergency2);
	if (CheckSoundMem(Over) == 0)PlaySoundMem(Over, DX_PLAYTYPE_LOOP);//Over���Đ����łȂ���Ή���炷


	//�t�F�[�h�A�E�g															
	if (overBright >= 70) {
		overBright -= 0.35f;
	}
	SetDrawBright(overBright, overBright, overBright);
	DrawGraph(0, 0, ImageMng::GetInstance().SetID("image/landBG.png"), true);

	//��ʊO�ɏo�ăQ�[���I�[�o�[�ɂȂ�����
	if (OutOfScreen) {
		//�m�C�Y�̕`��
		for (int x = 0; x < SCREEN_SIZE_X; x++)
		{
			for (int y = 0; y < SCREEN_SIZE_Y; y++)
			{
				auto randomY = GetRand(10000);

				DrawPixel(x, y + randomY, GetColor(255, 255, 255));
			}
		}
		if (playerVec.y < 0)
		{
			paint_y++;//�`�悷��Ƃ��̂��炷�l
		}
		else if (playerVec.y > 0) {
			paint_y--;//�`�悷��Ƃ��̂��炷�l
		}
		if (playerVec.x > 0) {
			paint_x++;//�`�悷��Ƃ��̂��炷�l
		}
		else if (playerVec.x < 0) {
			paint_x--;//�`�悷��Ƃ��̂��炷�l
		}
	}
	else {	//����ȊO�̎�(�R���؂�)
		paint_x = 0;//�`�悷��Ƃ��̂��炷�l
		paint_y--;	//�`�悷��Ƃ��̂��炷�l
	}
	//���@�̕`��

	if (UFOFlag == true) {	//���@��ufo�̎�
		DrawRotaGraph(Ppos_x + paint_x, Ppos_y - paint_y, 1.0, playerAngle, ImageMng::GetInstance().SetID("image/ufo.png"), true);
	}
	else {
		//���@�ʏ펞(���P�b�g)
		DrawRotaGraph(Ppos_x + paint_x, Ppos_y - paint_y, 1.0, playerAngle, ImageMng::GetInstance().SetID("image/player.png"), true);
	}
	//���f��or覐΂ɓ������ăQ�[���I�[�o�[�̎�
	//if (bomFlag == true) {	
	if (hitCheck == true) {
		if (AnimCnt >= 11) {
			AnimCnt = 0;
		}
		if (AnimTime++ % 10 == 0)
		{
			AnimCnt++;
		}

		DrawGraph(Bpos_x, Bpos_y - paint_y, DieAnim[AnimCnt], true);	//�����G�t�F�N�g�`��
	}



	// ��ײor����
	if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		time = 0;
		AnimCnt = 0;
		AnimTime = 0;
		clearCnt = 0;
		clearCheck = false;
		landingCheck = false;
		landingFlag = false;
		returnFlag = false;
		getSample = false;
		UFOFlag = false;
		PlaySoundMem(Decision, DX_PLAYTYPE_BACK);
		if (CheckSoundMem(Over) == 1)StopSoundMem(Over);// Over���Đ����Ȃ�Over�̉����~�߂�
														// �w�i�̍폜
		std::vector<BackGround*>::iterator itrBG = backVec.begin();
		/*while (itrBG != backVec.end())
		{
			delete(*itrBG);
			itrBG = backVec.erase(itrBG);
			BackGraundCnt--;
		}*/
		titleBright = 0;
		if(titleShake > 0)
		titleShake = 0;
		rocketSize = 0.0f;
		rocketPos = { SCREEN_SIZE_X / 2,SCREEN_SIZE_Y - 150 };
		lightFlag = false;
		pushSpace = false;
		UFOFlag = false;

		GtskPtr = &GameTask::GameTitle;
	}
	if (KeyMng::GetInstance().trgKey[P1_SPACE] && !landGameCheck)
	{
		AnimCnt = 0;
		AnimTime = 0;

		if (!getSample)
		{
			MarsCnt--;
			time = 0;
			AnimCnt = 0;
			clearCnt = 0;
			clearCheck = false;
			landingCheck = false;
			landingFlag = false;
			returnFlag = false;
			getSample = false;
			GtskPtr = &GameTask::GameInit;
		}
		else
		{
			auto setCnt = 0;
			auto itrPos = VECTOR3(0, 0);
			for (auto itr : bpList)
			{
				itrPos = itr->GetPos();
				itr->SetPos(VECTOR3(tSetPos[setCnt].x, tSetPos[setCnt].y + (pltrgPos.y - targetSet[StageCnt].y)));
				setCnt++;
			}
			(*player)->SetPos(VECTOR3(pltrgScr.x*1.2f,playerPos.y));
			(*player)->SetVec(VECTOR3(0,0.1f));
			(*player)->SetEnergy(100.0f);
			(*player)->SetplPos(VECTOR3(setplPos.x, setplPos.y));
			SetScrollPos(-targetVec);

			//ScrollPos.y = (pltrgPos.y - targetSet[StageCnt].y);
			//ScrollPos.y += pltrgScr.y - pltrgPos.y;
			setCount = true;
			landingCheck = false;
			landAnimFlag = false;
			landingFlag = true;
			clearCheck = true;						// �ر�\��Ԃɂ���
			hitCheck = false;
			clearCnt = 0;
			GtskPtr = &GameTask::GameMain;
		}
		if (CheckSoundMem(Over) == 1)StopSoundMem(Over);// Over���Đ����Ȃ�Over�̉����~�߂�

		
	}

	// �����߲�ē��B��
	if (KeyMng::GetInstance().trgKey[P1_SPACE] && landGameCheck)
	{
		landGameCheck = false;

		if (CheckSoundMem(Over) == 1)StopSoundMem(Over);// Over���Đ����Ȃ�Over�̉����~�߂�

		GtskPtr = &GameTask::GameLanding;
	}

	if (landingCnt[0] < 255)
	{
		landingCnt[0] += 5;
	}
	if (landingCnt[1] < 255)
	{
		landingCnt[1] += 5;
	}

	if (landingCnt[0] < landingCnt[1])
	{
		SetDrawBright(landingCnt[0], landingCnt[0], landingCnt[0]);
	}
	else
	{
		SetDrawBright(landingCnt[1], landingCnt[1], landingCnt[1]);
	}


	DrawString(0, 0, "GameResult", 0xffffff);


	SetFontSize(50);		// ̫�Ă̻���
	SetFontThickness(8);	// ̫�Ă̑���
	ChangeFont("Ailerons");
	DrawString(SCREEN_CENTER_X - SCREEN_SIZE_X / 4, SCREEN_SIZE_Y / 2, "GAME OVER", 0xffffff);
	SetFontSize(20);		// ̫�Ă̻���
	SetFontThickness(8);	// ̫�Ă̑���
	ChangeFont("MS�S�V�b�N");

	//DrawFormatStringF(10, 500, GetColor(255, 255, 255), "���� %d flag %d return %d clear %d sample %d", landingCheck, landingFlag, returnFlag, clearCheck, getSample);
	/*DrawFormatStringF(10, 550, GetColor(255, 255, 255), "playerX %f playerY %f", pltrgScr.x, pltrgScr.y);
	DrawFormatStringF(10, 600, GetColor(255, 255, 255), "pltrgX %f pltrgY %f", pltrgPos.x, pltrgPos.y);*/
	ScreenFlip();

	return 0;
}

int GameTask::GameClear(void)
{
	ClsDrawScreen();

	if (KeyMng::GetInstance().trgKey[P1_SPACE])
	{
		pushSpace = false;
		UFOFlag = false;
		titleShake = 0;
		GtskPtr = &GameTask::GameTitle;
	}

	if (MaxTime >= 2000)
	{
		DrawGraph(0, 0, IMAGE_ID("image/Result/result.png"), true);
		DrawGraph(0, 400, IMAGE_ID("image/Result/Stage2Clear.png"), true);
	}
	else
	{
		DrawGraph(0, 0, IMAGE_ID("image/Result/result2.png"), true);
		DrawGraph(0, 400, IMAGE_ID("image/Result/Stage3Clear.png"), true);
	}

	//DrawString(0, 0, "GameClear", 0xffffff);

	//DrawFormatStringF(10, 600, GetColor(255, 255, 255), "MaxTime %d", MaxTime);

	ScreenFlip();

	return 0;
}


std::list<obj_ptr>::iterator GameTask::AddObjlist(obj_ptr && objPtr)
{
	objList.push_back(objPtr);
	auto itr = objList.end();
	itr--;
	return itr;
}

std::list<bp_ptr>::iterator GameTask::AddBplist(bp_ptr && bpPtr)
{
	bpList.push_back(bpPtr);
	auto itr = bpList.end();
	itr--;
	return itr;
}


