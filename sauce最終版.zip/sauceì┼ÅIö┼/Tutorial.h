#pragma once

class Tutorial {
public:
	Tutorial();
	~Tutorial();
	void Init();
	void Draw();
	void Update();
private:
	int alpha = 255;
	int count = 0;
	float keyAlpha = 255.0f;
	float tipsAlpha = 0.0f;
};