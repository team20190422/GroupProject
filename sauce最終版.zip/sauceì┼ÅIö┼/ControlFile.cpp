#include "GameTask.h"
#include "ControlFile.h"

ControlFile::ControlFile()
{
}

ControlFile::~ControlFile()
{
}

void ControlFile::Update(int score)
{
	scr = score;
	ShowScore();
	LoadScore();
}

void ControlFile::SaveScore(int sco)
{
	fopen_s(&file,"score/score.txt","a");
	fprintf_s(file, "%03d ",sco);
	fclose(file);
}

void ControlFile::ShowScore()
{
	//SetFontSize(20);
	//DrawFormatString(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 0xffffff,"%d\n",scr);
}

void ControlFile::LoadScore()
{
	error = fopen_s(&file, "score/score.txt", "r");
	if (error != 0)
	{
		int a = 0;
	}

	while(fgets(str, 100, file) != nullptr)
	{
		std::atoi(str);
		//DrawFormatString(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2 + 100, 0xffffff, "%s\n", str);
	}
	fclose(file);
}
