#include "GameTask.h"
#include "ControlFile.h"

ControlFile::ControlFile()
{
}

ControlFile::~ControlFile()
{
}

void ControlFile::Update(int score)
{
	scr = score;
	SaveScore(score);
	ShowScore();
	LoadScore();
}

void ControlFile::SaveScore(int sco)
{
	fopen_s(&file,"score/score.txt","a");
	fprintf_s(file, "%d\n",sco);
	fclose(file);
}

void ControlFile::ShowScore()
{
	SetFontSize(10);
	DrawFormatString(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2, 0xffffff,"%d\n",scr);
}

void ControlFile::LoadScore()
{
	fopen_s(&file, "score/score.txt", "r");
	DrawFormatString(SCREEN_SIZE_X / 2, SCREEN_SIZE_Y / 2 + 100, 0xffffff, "%d\n", file);
	fclose(file);
}
