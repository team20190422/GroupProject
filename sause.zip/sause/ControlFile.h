#pragma once

#include <stdio.h>

class ControlFile {
public:
	ControlFile();
	~ControlFile();

	void Update(int);
	void SaveScore(int);
	void ShowScore();
	void LoadScore();
private:
	FILE *file;
	int scr;
};