#pragma once
#include "BasePlanet.h"

class Mars :
	public BasePlanet
{
public:
	Mars(VECTOR3 pos, int marsCnt);
	~Mars();	

	const VECTOR3 & GetPos(void);
	bool SetPos(VECTOR3 pos);

private:
	VECTOR3 mPos = { 0,0 };
	VECTOR2 imageSize = { 0,0 };
	VECTOR3 radianPos = { 0,0 };
	double time = 0;
	float gravity = 1.5f;
	int imageCnt = 0;
	int nextPlanet = 0;
	int planetImage = 0;
	int mokutekichi = 0;
	int planetTime = 0;

protected:
	void Init();
	void Update();
	void Draw();

};

